package bg.tu_varna.sit.ticket_centar.data.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlacePriceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getPlacePriceId() {
        PlacePrice pp = new PlacePrice();
        pp.setPlacePriceId(4L);
        assertEquals(4L, pp.getPlacePriceId());
    }

    @Test
    void setPlacePriceId() {
        PlacePrice pp = new PlacePrice();
        pp.setPlacePriceId(4L);
        assertEquals(4L, pp.getPlacePriceId());
    }

    @Test
    void getPlacePrice() {
        PlacePrice pp = new PlacePrice();
        pp.setPlacePrice(4.50);
        assertEquals(4.50, pp.getPlacePrice());
    }

    @Test
    void setPlacePrice() {
        PlacePrice pp = new PlacePrice();
        pp.setPlacePrice(4.50);
        assertEquals(4.50, pp.getPlacePrice());
    }

    @Test
    void getPlaceType() {
        PlacePrice pp = new PlacePrice();
        pp.setPlaceType("type");
        assertEquals("type", pp.getPlaceType());
    }

    @Test
    void setPlaceType() {
        PlacePrice pp = new PlacePrice();
        pp.setPlaceType("type");
        assertEquals("type", pp.getPlaceType());
    }
}