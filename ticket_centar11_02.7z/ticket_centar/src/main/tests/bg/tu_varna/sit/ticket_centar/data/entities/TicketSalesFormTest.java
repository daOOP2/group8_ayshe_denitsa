package bg.tu_varna.sit.ticket_centar.data.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TicketSalesFormTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getTicketSalesFormId() {
        TicketSalesForm t = new TicketSalesForm();
        t.setTicketSalesFormId(7L);
        assertEquals(7L, t.getTicketSalesFormId());
    }

    @Test
    void setTicketSalesFormId() {
        TicketSalesForm t = new TicketSalesForm();
        t.setTicketSalesFormId(7L);
        assertEquals(7L, t.getTicketSalesFormId());
    }

    @Test
    void getClientFirstName() {
        TicketSalesForm t = new TicketSalesForm();
        t.setClientFirstName("first");
        assertEquals("first", t.getClientFirstName());
    }

    @Test
    void setClientFirstName() {
        TicketSalesForm t = new TicketSalesForm();
        t.setClientFirstName("first");
        assertEquals("first", t.getClientFirstName());
    }

    @Test
    void getClientLastName() {
        TicketSalesForm t = new TicketSalesForm();
        t.setClientLastName("last");
        assertEquals("last", t.getClientLastName());
    }

    @Test
    void setClientLastName() {
        TicketSalesForm t = new TicketSalesForm();
        t.setClientLastName("last");
        assertEquals("last", t.getClientLastName());
    }

    @Test
    void getEvent() {
        Event e = new Event();
        TicketSalesForm t = new TicketSalesForm();
        t.setEvent(e);
        assertEquals(e, t.getEvent());
    }

    @Test
    void setEvent() {
        Event e = new Event();
        TicketSalesForm t = new TicketSalesForm();
        t.setEvent(e);
        assertEquals(e, t.getEvent());
    }

    @Test
    void getDistributor() {
        Distributor d = new Distributor();
        TicketSalesForm t = new TicketSalesForm();
        t.setDistributor(d);
        assertEquals(d, t.getDistributor());
    }

    @Test
    void setDistributor() {
        Distributor d = new Distributor();
        TicketSalesForm t = new TicketSalesForm();
        t.setDistributor(d);
        assertEquals(d, t.getDistributor());
    }

    @Test
    void getPlacePrice() {
        PlacePrice pp = new PlacePrice();
        TicketSalesForm t = new TicketSalesForm();
        t.setPlacePrice(pp);
        assertEquals(pp, t.getPlacePrice());
    }

    @Test
    void setPlacePrice() {
        PlacePrice pp = new PlacePrice();
        TicketSalesForm t = new TicketSalesForm();
        t.setPlacePrice(pp);
        assertEquals(pp, t.getPlacePrice());
    }

    @Test
    void getPhoneNumber() {
        TicketSalesForm t = new TicketSalesForm();
        t.setPhoneNumber("+359899366054");
        assertEquals("+359899366054", t.getPhoneNumber());
    }

    @Test
    void setPhoneNumber() {
        TicketSalesForm t = new TicketSalesForm();
        t.setPhoneNumber("+359899366054");
        assertEquals("+359899366054", t.getPhoneNumber());
    }

    @Test
    void getSaleDate() {
        TicketSalesForm t = new TicketSalesForm();
        t.setSaleDate("2022-02-10");
        assertEquals("2022-02-10", t.getSaleDate());
    }

    @Test
    void setSaleDate() {
        TicketSalesForm t = new TicketSalesForm();
        t.setSaleDate("2022-02-10");
        assertEquals("2022-02-10", t.getSaleDate());
    }
}