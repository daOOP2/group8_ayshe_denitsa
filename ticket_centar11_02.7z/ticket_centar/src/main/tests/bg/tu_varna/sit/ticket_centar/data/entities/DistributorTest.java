package bg.tu_varna.sit.ticket_centar.data.entities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DistributorTest {

    @Test
    void getDistributorId() {
        Distributor d = new Distributor();
        d.setDistributorId(2L);
        assertEquals(2L, (long) d.getDistributorId());
    }

    @Test
    void setDistributorId() {
        Distributor d = new Distributor();
        d.setDistributorId(2L);
        assertEquals(2L, (long) d.getDistributorId());
    }

    @Test
    void getDistributorFirstName() {
        Distributor d = new Distributor();
        d.setDistributorFirstName("firstName");
        assertEquals("firstName", d.getDistributorFirstName());
    }

    @Test
    void setDistributorFirstName() {
        Distributor d = new Distributor();
        d.setDistributorFirstName("firstName");
        assertEquals("firstName", d.getDistributorFirstName());
    }

    @Test
    void getDistributorLastName() {
        Distributor d = new Distributor();
        d.setDistributorLastName("lastName");
        assertEquals("lastName", d.getDistributorLastName());
    }

    @Test
    void setDistributorLastName() {
        Distributor d = new Distributor();
        d.setDistributorLastName("lastName");
        assertEquals("lastName", d.getDistributorLastName());
    }

    @Test
    void getDistributorUsername() {
        Distributor d = new Distributor();
        d.setDistributorUsername("Username");
        assertEquals("Username", d.getDistributorUsername());
    }

    @Test
    void setDistributorUsername() {
        Distributor d = new Distributor();
        d.setDistributorUsername("Username");
        assertEquals("Username", d.getDistributorUsername());
    }

    @Test
    void getDistributorPassword() {
        Distributor d = new Distributor();
        d.setDistributorPassword("Password");
        assertEquals("Password", d.getDistributorPassword());
    }

    @Test
    void setDistributorPassword() {
        Distributor d = new Distributor();
        d.setDistributorPassword("Password");
        assertEquals("Password", d.getDistributorPassword());
    }

    @Test
    void getDistributorEmail() {
        Distributor d = new Distributor();
        d.setDistributorEmail("email");
        assertEquals("email", d.getDistributorEmail());
    }

    @Test
    void setDistributorEmail() {
        Distributor d = new Distributor();
        d.setDistributorEmail("email");
        assertEquals("email", d.getDistributorEmail());
    }

    @Test
    void getDistributorPhoneNumber() {
        Distributor d = new Distributor();
        d.setDistributorPhoneNumber("+359899633000");
        assertEquals("+359899633000", d.getDistributorPhoneNumber());
    }

    @Test
    void setDistributorPhoneNumber() {
        Distributor d = new Distributor();
        d.setDistributorPhoneNumber("+359899633000");
        assertEquals("+359899633000", d.getDistributorPhoneNumber());
    }

    @Test
    void getDistributorAddress() {
        Distributor d = new Distributor();
        d.setDistributorAddress("Shumen");
        assertEquals("Shumen", d.getDistributorAddress());
    }

    @Test
    void setDistributorAddress() {
        Distributor d = new Distributor();
        d.setDistributorAddress("Shumen");
        assertEquals("Shumen", d.getDistributorAddress());
    }

    @Test
    void getDistributorHonorarium() {
        Distributor d = new Distributor();
        d.setDistributorHonorarium(150.50);
        assertEquals(150.50, d.getDistributorHonorarium());
    }

    @Test
    void setDistributorHonorarium() {
        Distributor d = new Distributor();
        d.setDistributorHonorarium(150.50);
        assertEquals(150.50, d.getDistributorHonorarium());
    }

    @Test
    void getAdmin() {
        Administrator a = new Administrator();
        Distributor d = new Distributor();
        d.setAdmin(a);
        assertEquals(a, d.getAdmin());
    }

    @Test
    void setAdmin() {
        Administrator a = new Administrator();
        Distributor d = new Distributor();
        d.setAdmin(a);
        assertEquals(a, d.getAdmin());
    }
}