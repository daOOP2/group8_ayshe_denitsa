package bg.tu_varna.sit.ticket_centar.business.servicec;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TicketSalesFormServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getInstance() {
    }

    @Test
    void getAllForms() {
    }

    @Test
    void getSoldTicketsForEvent() {
    }

    @Test
    void soldTicketsForLastWeek() {
    }

    @Test
    void getClientFullName() {
    }

    @Test
    void checkPhoneNumberIfExistsOrCorrect() {
    }

    @Test
    void checkForDistributor() {
    }

    @Test
    void checkMaxTicketsPerPerson() {
    }

    @Test
    void checkForSoldOut() {
    }

    @Test
    void checkClientInformation() {
    }

    @Test
    void saveTicketSalesForm() {
    }

    @Test
    void updateTicketSalesForm() {
    }

    @Test
    void deleteTicketSalesForm() {
    }

    @Test
    void getTicketSalesFormView() {
    }

    @Test
    void getUpdateDeleteTicketSalesFormView() {
    }
}