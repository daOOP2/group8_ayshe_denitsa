package bg.tu_varna.sit.ticket_centar.business.servicec;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventDistributorServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getInstance() {
    }

    @Test
    void getAllEventDistributors() {
    }

    @Test
    void getEventsByDistributor() {
    }

    @Test
    void getLastAddedEvents() {
    }

    @Test
    void saveEventDistributor() {
    }

    @Test
    void deleteEventDistributor() {
    }

    @Test
    void getEventDistributorsView() {
    }

    @Test
    void getDeleteEventDistributorsView() {
    }
}