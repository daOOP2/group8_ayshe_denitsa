package bg.tu_varna.sit.ticket_centar.business.servicec;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getInstance() {
    }

    @Test
    void getAllEvents() {
    }

    @Test
    void getEventsByOrganizer() {
    }

    @Test
    void setStatus() {
    }

    @Test
    void getEventByName() {
    }

    @Test
    void eventsThisMonth() {
    }

    @Test
    void getInfo() {
    }

    @Test
    void saveEvent() {
    }

    @Test
    void checkNameIfAlreadyExists() {
    }

    @Test
    void checkIfNumberOfPlacesIsEnough() {
    }

    @Test
    void updateEvent() {
    }

    @Test
    void getNewEventView() {
    }

    @Test
    void getUpdateEventView() {
    }
}