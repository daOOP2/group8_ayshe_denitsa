package bg.tu_varna.sit.ticket_centar.data.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventPlacesTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getEventPlacesId() {
        EventPlaces ep = new EventPlaces();
        ep.setEventPlacesId(1L);
        assertEquals(1L, ep.getEventPlacesId());
    }

    @Test
    void setEventPlacesId() {
        EventPlaces ep = new EventPlaces();
        ep.setEventPlacesId(1L);
        assertEquals(1L, ep.getEventPlacesId());
    }

    @Test
    void getNumberOfTickets() {
        EventPlaces ep = new EventPlaces();
        ep.setNumberOfTickets(350);
        assertEquals(350, ep.getNumberOfTickets());
    }

    @Test
    void setNumberOfTickets() {
        EventPlaces ep = new EventPlaces();
        ep.setNumberOfTickets(350);
        assertEquals(350, ep.getNumberOfTickets());
    }

    @Test
    void getEvent() {
        Event e = new Event();
        e.setEventName("name");
        EventPlaces ep = new EventPlaces();
        ep.setEvent(e);
        assertEquals(e.getEventName(), ep.getEvent().getEventName());
    }

    @Test
    void setEvent() {
        Event e = new Event();
        EventPlaces ep = new EventPlaces();
        ep.setEvent(e);
        assertEquals(e, ep.getEvent());
    }

    @Test
    void getPlacePrice() {
        PlacePrice p = new PlacePrice();
        EventPlaces ep = new EventPlaces();
        ep.setPlacePrice(p);
        assertEquals(p, ep.getPlacePrice());
    }

    @Test
    void setPlacePrice() {
        PlacePrice p = new PlacePrice();
        EventPlaces ep = new EventPlaces();
        ep.setPlacePrice(p);
        assertEquals(p, ep.getPlacePrice());
    }
}