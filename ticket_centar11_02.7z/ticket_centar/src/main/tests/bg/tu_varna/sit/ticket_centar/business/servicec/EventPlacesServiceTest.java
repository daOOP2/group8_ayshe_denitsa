package bg.tu_varna.sit.ticket_centar.business.servicec;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventPlacesServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getInstance() {
    }

    @Test
    void getAllEventPlaces() {
    }

    @Test
    void getEventPlacesByEventName() {
    }

    @Test
    void saveEventPlaces() {
    }

    @Test
    void updateEventPlaces() {
    }

    @Test
    void getEventPlacesView() {
    }

    @Test
    void getUpdateDeleteEventPlacesView() {
    }
}