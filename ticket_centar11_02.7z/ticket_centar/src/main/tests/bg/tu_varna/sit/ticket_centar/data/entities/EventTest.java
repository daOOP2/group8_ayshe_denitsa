package bg.tu_varna.sit.ticket_centar.data.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getEventId() {
        Event e = new Event();
        e.setEventId(1L);
        assertEquals(1L, e.getEventId());
    }

    @Test
    void setEventId() {
        Event e = new Event();
        e.setEventId(1L);
        assertEquals(1L, e.getEventId());
    }

    @Test
    void getEventName() {
        Event e = new Event();
        e.setEventName("a");
        assertEquals("a", e.getEventName());
    }

    @Test
    void setEventName() {
        Event e = new Event();
        e.setEventName("a");
        assertEquals("a", e.getEventName());
    }

    @Test
    void getEventType() {
        Event e = new Event();
        e.setEventType("a");
        assertEquals("a", e.getEventType());
    }

    @Test
    void setEventType() {
        Event e = new Event();
        e.setEventType("a");
        assertEquals("a", e.getEventType());
    }

    @Test
    void getEventStatus() {
        Event e = new Event();
        e.setEventStatus("status");
        assertEquals("status", e.getEventStatus());
    }

    @Test
    void setEventStatus() {
        Event e = new Event();
        e.setEventStatus("status");
        assertEquals("status", e.getEventStatus());
    }

    @Test
    void getEventNumberOfPlaces() {
        Event e = new Event();
        e.setEventNumberOfPlaces(6);
        assertEquals(6, e.getEventNumberOfPlaces());
    }

    @Test
    void setEventNumberOfPlaces() {
        Event e = new Event();
        e.setEventNumberOfPlaces(6);
        assertEquals(6, e.getEventNumberOfPlaces());
    }

    @Test
    void getEventDate() {
        Event e = new Event();
        e.setEventDate("2022-02-13");
        assertEquals("2022-02-13", e.getEventDate());
    }

    @Test
    void setEventDate() {
        Event e = new Event();
        e.setEventDate("2022-02-13");
        assertEquals("2022-02-13", e.getEventDate());
    }

    @Test
    void getDateOfCreation() {
        Event e = new Event();
        e.setDateOfCreation("2022-02-13");
        assertEquals("2022-02-13", e.getDateOfCreation());
    }

    @Test
    void setDateOfCreation() {
        Event e = new Event();
        e.setDateOfCreation("2022-02-13");
        assertEquals("2022-02-13", e.getDateOfCreation());
    }

    @Test
    void getMaxNumberOfTicketsPerPerson() {
        Event e = new Event();
        e.setMaxNumberOfTicketsPerPerson(2);
        assertEquals(2, e.getMaxNumberOfTicketsPerPerson());
    }

    @Test
    void setMaxNumberOfTicketsPerPerson() {
        Event e = new Event();
        e.setMaxNumberOfTicketsPerPerson(2);
        assertEquals(2, e.getMaxNumberOfTicketsPerPerson());
    }

    @Test
    void getOrganizer() {
        Organizer o = new Organizer();
        Event e = new Event();
        e.setOrganizer(o);
        assertEquals(o, e.getOrganizer());
    }

    @Test
    void setOrganizer() {
        Organizer o = new Organizer();
        Event e = new Event();
        e.setOrganizer(o);
        assertEquals(o, e.getOrganizer());
    }

    @Test
    void getAddress() {
        Event e = new Event();
        e.setAddress("address");
        assertEquals("address", e.getAddress());
    }

    @Test
    void setAddress() {
        Event e = new Event();
        e.setAddress("address");
        assertEquals("address", e.getAddress());
    }

    @Test
    void getEventDetails() {
        Event e = new Event();
        e.setEventDetails("details");
        assertEquals("details", e.getEventDetails());
    }

    @Test
    void setEventDetails() {
        Event e = new Event();
        e.setEventDetails("details");
        assertEquals("details", e.getEventDetails());
    }
}