package bg.tu_varna.sit.ticket_centar.business.servicec;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrganizerServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void setUsername() {
    }

    @Test
    void getUsername() {
    }

    @Test
    void getInstance() {
    }

    @Test
    void getAllOrganizers() {
    }

    @Test
    void getOrganizerByUsername() {
    }

    @Test
    void logInOrganizer() {
    }

    @Test
    void saveOrganizer() {
    }

    @Test
    void checkInputData() {
    }

    @Test
    void getOrganizerInfo() {
    }

    @Test
    void getOrganizerModelByID() {
    }

    @Test
    void checkPhoneNumberIfExistsOrCorrect() {
    }

    @Test
    void checkEmailIfExists() {
    }

    @Test
    void updateOrganizer() {
    }

    @Test
    void getOrganizerMenuView() {
    }

    @Test
    void getNewOrganizerView() {
    }

    @Test
    void getProfileOrganizersView() {
    }

    @Test
    void getOrganizerNotificationsView() {
    }

    @Test
    void getOrganizerEventsView() {
    }

    @Test
    void getUpdateOrganizerView() {
    }
}