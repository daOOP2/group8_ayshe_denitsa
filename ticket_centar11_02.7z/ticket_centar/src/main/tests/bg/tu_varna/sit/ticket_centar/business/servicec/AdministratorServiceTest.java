package bg.tu_varna.sit.ticket_centar.business.servicec;

import bg.tu_varna.sit.ticket_centar.data.entities.Administrator;
import bg.tu_varna.sit.ticket_centar.data.repositories.AdministratorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AdministratorServiceTest {



    @BeforeEach
    void setUp()
    {


    }

    @Test
    void getUsername() {

    }

    @Test
    void getAllAdministrators() {
    }

    @Test
    void getAdminByUsername() {
    }

    @Test
    void logInAdmin() {
    }
}