package bg.tu_varna.sit.ticket_centar.data.entities;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrganizerTest {

    @Test
    void getOrganizerId() {
        Organizer o = new Organizer();
        o.setOrganizerId(1L);
        assertEquals(1L, o.getOrganizerId());
    }

    @Test
    void setOrganizerId() {
        Organizer o = new Organizer();
        o.setOrganizerId(1L);
        assertEquals(1L, o.getOrganizerId());
    }

    @Test
    void getOrganizerFirstName() {
        Organizer o = new Organizer();
        o.setOrganizerFirstName("first");
        assertEquals("first", o.getOrganizerFirstName());
    }

    @Test
    void setOrganizerFirstName() {
        Organizer o = new Organizer();
        o.setOrganizerFirstName("first");
        assertEquals("first", o.getOrganizerFirstName());
    }

    @Test
    void getOrganizerLastName() {
        Organizer o = new Organizer();
        o.setOrganizerLastName("last");
        assertEquals("last", o.getOrganizerLastName());
    }

    @Test
    void setOrganizerLastName() {
        Organizer o = new Organizer();
        o.setOrganizerLastName("last");
        assertEquals("last", o.getOrganizerLastName());
    }

    @Test
    void getOrganizerUsername() {
        Organizer o = new Organizer();
        o.setOrganizerUsername("user");
        assertEquals("user", o.getOrganizerUsername());
    }

    @Test
    void setOrganizerUsername() {
        Organizer o = new Organizer();
        o.setOrganizerUsername("user");
        assertEquals("user", o.getOrganizerUsername());
    }

    @Test
    void getOrganizerPassword() {
        Organizer o = new Organizer();
        o.setOrganizerPassword("pass");
        assertEquals("pass", o.getOrganizerPassword());
    }

    @Test
    void setOrganizerPassword() {
        Organizer o = new Organizer();
        o.setOrganizerPassword("pass");
        assertEquals("pass", o.getOrganizerPassword());
    }

    @Test
    void getOrganizerEmail() {
        Organizer o = new Organizer();
        o.setOrganizerEmail("email");
        assertEquals("email", o.getOrganizerEmail());
    }

    @Test
    void setOrganizerEmail() {
        Organizer o = new Organizer();
        o.setOrganizerEmail("email");
        assertEquals("email", o.getOrganizerEmail());
    }

    @Test
    void getOrganizerPhoneNumber() {
        Organizer o = new Organizer();
        o.setOrganizerPhoneNumber("+359899366054");
        assertEquals("+359899366054", o.getOrganizerPhoneNumber());
    }

    @Test
    void setOrganizerPhoneNumber() {
        Organizer o = new Organizer();
        o.setOrganizerPhoneNumber("+359899366054");
        assertEquals("+359899366054", o.getOrganizerPhoneNumber());
    }

    @Test
    void getOrganizerAddress() {
        Organizer o = new Organizer();
        o.setOrganizerAddress("address");
        assertEquals("address", o.getOrganizerAddress());
    }

    @Test
    void setOrganizerAddress() {
        Organizer o = new Organizer();
        o.setOrganizerAddress("address");
        assertEquals("address", o.getOrganizerAddress());
    }

    @Test
    void getOrganizerHonorarium() {
        Organizer o = new Organizer();
        o.setOrganizerHonorarium(150.0);
        assertEquals(150.0, o.getOrganizerHonorarium());
    }

    @Test
    void setOrganizerHonorarium() {
        Organizer o = new Organizer();
        o.setOrganizerHonorarium(150.0);
        assertEquals(150.0, o.getOrganizerHonorarium());
    }

    @Test
    void getAdmin() {
        Administrator a = new Administrator();
        Organizer o = new Organizer();
        o.setAdmin(a);
        assertEquals(a, o.getAdmin());
    }

    @Test
    void setAdmin() {
        Administrator a = new Administrator();
        Organizer o = new Organizer();
        o.setAdmin(a);
        assertEquals(a, o.getAdmin());
    }
}