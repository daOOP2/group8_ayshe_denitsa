package bg.tu_varna.sit.ticket_centar.data.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EventDistributorTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getEventDistributorId() {
        EventDistributor ed = new EventDistributor();
        ed.setEventDistributorId(1L);
        assertEquals(1L, ed.getEventDistributorId());
    }

    @Test
    void setEventDistributorId() {
        EventDistributor ed = new EventDistributor();
        ed.setEventDistributorId(1L);
        assertEquals(1L, ed.getEventDistributorId());
    }

    @Test
    void getDistributor() {
        Distributor d = new Distributor();
        EventDistributor ed = new EventDistributor();
        ed.setDistributor(d);
        assertEquals(d, ed.getDistributor());
    }

    @Test
    void setDistributor() {
        Distributor d = new Distributor();
        EventDistributor ed = new EventDistributor();
        ed.setDistributor(d);
        assertEquals(d, ed.getDistributor());
    }

    @Test
    void getEvent() {
        Event e = new Event();
        EventDistributor ed = new EventDistributor();
        ed.setEvent(e);
        assertEquals(e, ed.getEvent());
    }

    @Test
    void setEvent() {
        Event e = new Event();
        EventDistributor ed = new EventDistributor();
        ed.setEvent(e);
        assertEquals(e, ed.getEvent());
    }

    @Test
    void getDate() {
        EventDistributor ed = new EventDistributor();
        ed.setDate("2022-02-13");
        assertEquals("2022-02-13", ed.getDate());
    }

    @Test
    void setDate() {
        EventDistributor ed = new EventDistributor();
        ed.setDate("2022-02-13");
        assertEquals("2022-02-13", ed.getDate());
    }
}