package bg.tu_varna.sit.ticket_centar.business.servicec;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DistributorRatingServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getInstance() {
    }

    @Test
    void getAllDistributorRatings() {
    }

    @Test
    void getSummaryRating() {
    }

    @Test
    void getRatingPercentage() {
    }

    @Test
    void checkIfExists() {
    }

    @Test
    void saveDistributorRating() {
    }

    @Test
    void updateDistributorRating() {
    }

    @Test
    void deleteDistributorRating() {
    }

    @Test
    void getDistributorRatingView() {
    }

    @Test
    void getUpdateDeleteDistributorRatingView() {
    }
}