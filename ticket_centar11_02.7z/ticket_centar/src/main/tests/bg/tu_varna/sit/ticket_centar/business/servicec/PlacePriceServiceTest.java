package bg.tu_varna.sit.ticket_centar.business.servicec;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlacePriceServiceTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getInstance() {
    }

    @Test
    void getAllPrices() {
    }

    @Test
    void loadPrice() {
    }

    @Test
    void getPlaceByType() {
    }

    @Test
    void savePlacePrice() {
    }

    @Test
    void updatePlacePrice() {
    }

    @Test
    void deletePlacePrice() {
    }

    @Test
    void getPlacePriceView() {
    }

    @Test
    void getUpdateDeletePlacePriceView() {
    }
}