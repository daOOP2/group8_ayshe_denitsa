package bg.tu_varna.sit.ticket_centar.data.entities;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DistributorRatingTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getRatingId() {
        DistributorRating dr = new DistributorRating();
        dr.setRatingId(2L);
        assertEquals(2L, (long) dr.getRatingId());
    }

    @Test
    void setRatingId() {
        DistributorRating dr = new DistributorRating();
        dr.setRatingId(2L);
        assertEquals(2L, (long) dr.getRatingId());
    }

    @Test
    void getRatingPercentage() {
        DistributorRating dr = new DistributorRating();
        dr.setRatingPercentage(17.25);
        assertEquals(17.25, dr.getRatingPercentage());
    }

    @Test
    void setRatingPercentage() {
        DistributorRating dr = new DistributorRating();
        dr.setRatingPercentage(17.25);
        assertEquals(17.25, dr.getRatingPercentage());
    }

    @Test
    void getOrganizer() {
        Organizer o = new Organizer();
        DistributorRating dr = new DistributorRating();
        dr.setOrganizer(o);
        assertEquals(o, dr.getOrganizer());
    }

    @Test
    void setOrganizer() {
        Organizer o = new Organizer();
        DistributorRating dr = new DistributorRating();
        dr.setOrganizer(o);
        assertEquals(o, dr.getOrganizer());
    }

    @Test
    void getDistributor() {
        Distributor d = new Distributor();
        DistributorRating dr = new DistributorRating();
        dr.setDistributor(d);
        assertEquals(d, dr.getDistributor());
    }

    @Test
    void setDistributor() {
        Distributor d = new Distributor();
        DistributorRating dr = new DistributorRating();
        dr.setDistributor(d);
        assertEquals(d, dr.getDistributor());
    }
}