package bg.tu_varna.sit.ticket_centar.data.entities;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AdministratorTest {

    @Test
    void getAdminId() {
        Administrator a = new Administrator();
        a.setAdminId(1L);
        assertEquals(1L, (long) a.getAdminId());
    }

    @Test
    void setAdminId() {
        Administrator a = new Administrator();
        a.setAdminId(1L);
        assertEquals(1L, (long) a.getAdminId());
    }

    @Test
    void getAdminFirstName() {
        Administrator a = new Administrator();
        a.setAdminFirstName("name");
        assertSame("name", a.getAdminFirstName());
    }

    @Test
    void setAdminFirstName() {
        Administrator a = new Administrator();
        a.setAdminFirstName("name");
        assertSame("name", a.getAdminFirstName());
    }

    @Test
    void getAdminLastName() {
        Administrator a = new Administrator();
        a.setAdminLastName("name");
        assertSame("name", a.getAdminLastName());
    }

    @Test
    void setAdminLastName() {
        Administrator a = new Administrator();
        a.setAdminLastName("name");
        assertSame("name", a.getAdminLastName());
    }

    @Test
    void getAdminUsername() {
        Administrator a = new Administrator();
        a.setAdminUsername("username");
        assertSame("username", a.getAdminUsername());
    }

    @Test
    void setAdminUsername() {
        Administrator a = new Administrator();
        a.setAdminUsername("username");
        assertSame("username", a.getAdminUsername());
    }

    @Test
    void getAdminPassword() {
        Administrator a = new Administrator();
        a.setAdminPassword("password");
        assertSame("password", a.getAdminPassword());
    }

    @Test
    void setAdminPassword() {
        Administrator a = new Administrator();
        a.setAdminPassword("password");
        assertSame("password", a.getAdminPassword());
    }

    @Test
    void getAdminEmail() {
        Administrator a = new Administrator();
        a.setAdminEmail("email");
        assertSame("email", a.getAdminEmail());
    }

    @Test
    void setAdminEmail() {
        Administrator a = new Administrator();
        a.setAdminEmail("email");
        assertSame("email", a.getAdminEmail());
    }

    @Test
    void getAdminPhoneNumber() {
        Administrator a = new Administrator();
        a.setAdminPhoneNumber("+359899366054");
        assertSame("+359899366054", a.getAdminPhoneNumber());
    }

    @Test
    void setAdminPhoneNumber() {
        Administrator a = new Administrator();
        a.setAdminPhoneNumber("+359899366054");
        assertSame("+359899366054", a.getAdminPhoneNumber());
    }

    @Test
    void getAdminAddress() {
        Administrator a = new Administrator();
        a.setAdminAddress("Sofia");
        assertSame("Sofia", a.getAdminAddress());
    }

    @Test
    void setAdminAddress() {
        Administrator a = new Administrator();
        a.setAdminAddress("Sofia");
        assertSame("Sofia", a.getAdminAddress());
    }
}