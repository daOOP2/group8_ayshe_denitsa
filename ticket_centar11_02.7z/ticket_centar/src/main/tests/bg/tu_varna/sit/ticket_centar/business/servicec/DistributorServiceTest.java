package bg.tu_varna.sit.ticket_centar.business.servicec;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DistributorServiceTest {

    @BeforeEach
    void setUp() {
    }


    @Test
    void setUsername() {
    }

    @Test
    void getUsername() {
    }

    @Test
    void getAllDistributors() {
    }

    @Test
    void getDistributorByUsername() {
    }

    @Test
    void getDistributorModelByID() {
    }

    @Test
    void logInDistributor() {
    }

    @Test
    void getDistributorInfo() {
    }

    @Test
    void checkInputData() {
    }

    @Test
    void checkPhoneNumberIfExistsOrCorrect() {
    }

    @Test
    void checkEmailIfExists() {
    }

    @Test
    void saveDistributor() {
    }

    @Test
    void updateDistributor() {
    }

    @Test
    void getDistributorMenuView() {
    }

    @Test
    void getNewDistributorView() {
    }

    @Test
    void getProfileDistributorsView() {
    }

    @Test
    void getUpdateDistributorView() {
    }

    @Test
    void getDistributorEventsView() {
    }

    @Test
    void getDistributorNotificationsView() {
    }
}