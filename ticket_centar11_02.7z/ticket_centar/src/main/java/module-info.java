module bg.tu_varna.sit.ticket_centar {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires log4j;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires org.hibernate.orm.core;
    requires java.persistence;
    requires java.naming;
    requires java.sql;
    opens bg.tu_varna.sit.ticket_centar.data.entities to org.hibernate.orm.core;
    exports bg.tu_varna.sit.ticket_centar.data.entities;

    opens bg.tu_varna.sit.ticket_centar.data.access to org.hibernate.orm.core;
    exports bg.tu_varna.sit.ticket_centar.data.access;

    exports bg.tu_varna.sit.ticket_centar.application;
    opens bg.tu_varna.sit.ticket_centar.application to javafx.fxml;


    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Profiles;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Profiles to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Save;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Save to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Menu;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Menu to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Update;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Update to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.Save;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.Save to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.UpdateDelete;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.UpdateDelete to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.Menu;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.Menu to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.DistributorProfile;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.DistributorProfile to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.Notifications;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.Notifications to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Save;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Save to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.UpdateDelete;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.UpdateDelete to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Notifications;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Notifications to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.OrganizerProfile;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.OrganizerProfile to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.OrganizerMenu;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.OrganizerMenu to javafx.fxml;
    exports bg.tu_varna.sit.ticket_centar.presentation.controllers.LogInControllers;
    opens bg.tu_varna.sit.ticket_centar.presentation.controllers.LogInControllers to javafx.fxml;
}