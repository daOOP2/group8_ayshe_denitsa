package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.UpdateDelete;

import bg.tu_varna.sit.ticket_centar.business.servicec.EventService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.time.LocalDate;

public class UpdateEventController implements EventHandler<MouseEvent> {

    private final OrganizerService service_o = OrganizerService.getInstance();
    private final EventService service_e = EventService.getInstance();

    @FXML
    private Button  menu, update, load;

    @FXML private TextField result, max, details, number, name, type, status, address, number_of_places;

    @FXML DatePicker date;

    @FXML private void initialize() {
        menu.setOnMouseClicked(this);
        update.setOnMouseClicked(this); load.setOnMouseClicked(this);
        result.setEditable(false);
    }

    @Override public void handle(MouseEvent event) {
         if(event.getSource()==update)
        {
            EventModel m = new EventModel();
            m.setAddress(address.getText());
            m.setEvent_details(details.getText());
            m.setEvent_name(name.getText());
            m.setEvent_number_of_places(Integer.parseInt(number_of_places.getText()));
            m.setMax_number_of_tickets_per_person(Integer.parseInt(max.getText()));
            m.setEvent_type(type.getText());
            m.setEvent_status(status.getText());
            if(service_e.UpdateEvent(m,Long.valueOf(number.getText()))){result.setText("Successfully Updated!");}
            else {result.setText("Incorrect Data!");}
        }
        else if(event.getSource()==load)
        {
            EventModel m = service_e.getInfo(Long.parseLong(number.getText()));
            name.setText(m.getEvent_name());
            type.setText(m.getEvent_type());
            status.setText(m.getEvent_status());
            address.setText(m.getAddress());
            number_of_places.setText(String.valueOf(m.getEvent_number_of_places()));
            max.setText(String.valueOf(m.getMax_number_of_tickets_per_person()));
            details.setText(m.getEvent_details());
            date.setValue(LocalDate.parse(m.getEvent_date()));

        }
        else if (event.getSource() == menu)
        {
            service_o.getOrganizerMenuView(event);
        }
    }
}