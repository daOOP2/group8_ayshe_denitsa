package bg.tu_varna.sit.ticket_centar.presentation.models;

public class EventModel {
    private String event_name;
    private String event_type;
    private String event_status;
    private int event_number_of_places;
    private String event_date;
    private int max_number_of_tickets_per_person;
    private Long event_id;
    private String organizer_username;
    private String address;
    private String date_of_creation;
    private String event_details;

    public EventModel(){
        event_name="";
        event_type="";
        event_status="";
        event_number_of_places=0;
        event_date= "";
        max_number_of_tickets_per_person=0;
        event_id= Long.valueOf(0);
        organizer_username="";
        address="";
        date_of_creation="";
        event_details="";
    }

    public EventModel(String event_name, String event_type, String event_status, int event_number_of_places, String event_date, int max_number_of_tickets_per_person, Long event_id, String organizer_username, String address, String date_of_creation, String event_details){
        this.event_name=event_name;
        this.event_type=event_type;
        this.event_status=event_status;
        this.address=address;
        this.event_number_of_places=event_number_of_places;
        this.event_date=event_date;
        this.max_number_of_tickets_per_person=max_number_of_tickets_per_person;
        this.event_id=event_id;
        this.organizer_username=organizer_username;
        this.date_of_creation=date_of_creation;
        this.event_details=event_details;
    }

    public String getEvent_name(){return event_name;}
    public void setEvent_name(String event_name){this.event_name=event_name;}

    public String getEvent_type(){return event_type;}
    public void setEvent_type(String event_type){this.event_type=event_type;}

    public String getEvent_status(){return event_status;}
    public void setEvent_status(String event_status){this.event_status=event_status;}

    public int getEvent_number_of_places(){return event_number_of_places;}
    public void setEvent_number_of_places(int event_number_of_places){this.event_number_of_places=event_number_of_places;}

    public String getEvent_date(){return event_date;}
    public void setEvent_date(String event_date){this.event_date=event_date;}

    public int getMax_number_of_tickets_per_person(){return max_number_of_tickets_per_person;}
    public void setMax_number_of_tickets_per_person(int max_number_of_tickets_per_person){this.max_number_of_tickets_per_person=max_number_of_tickets_per_person;}

    public Long getEvent_id(){return event_id;}
    public void setEvent_id(Long event_id){this.event_id=event_id;}

    public String getOrganizer_username(){return organizer_username;}
    public void setOrganizer_username(String organizer_username){this.organizer_username=organizer_username;}

    public String getAddress(){return address;}
    public void setAddress(String address){this.address=address;}

    public String getDate_of_creation(){return date_of_creation;}
    public void setDate_of_creation(String date_of_creation){this.date_of_creation=date_of_creation;}

    public String getEvent_details(){return event_details;}
    public void setEvent_details(String event_details){this.event_details=event_details;}

    @Override
    public String toString() {
        return  String.format("%s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s", event_name, event_type, event_status, event_details, address, event_number_of_places, event_date, max_number_of_tickets_per_person, event_id, organizer_username, date_of_creation);
    }

}
