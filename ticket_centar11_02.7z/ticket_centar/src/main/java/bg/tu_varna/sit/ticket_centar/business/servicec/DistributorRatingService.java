package bg.tu_varna.sit.ticket_centar.business.servicec;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import bg.tu_varna.sit.ticket_centar.data.entities.DistributorRating;
import bg.tu_varna.sit.ticket_centar.data.repositories.DistributorRatingRepository;
import bg.tu_varna.sit.ticket_centar.presentation.models.DistributorRatingModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class DistributorRatingService {

    private final DistributorRatingRepository repository = DistributorRatingRepository.getInstance();
    private final DistributorService service_distributor = DistributorService.getInstance();
    private final OrganizerService service_organizer = OrganizerService.getInstance();

    public static DistributorRatingService getInstance() {return DistributorRatingService.DistributorRatingServiceHolder.INSTANCE;}

    private static class DistributorRatingServiceHolder { public static final DistributorRatingService INSTANCE = new DistributorRatingService();}

    public ObservableList<DistributorRatingModel> getAllDistributorRatings() {
        List<DistributorRating> ratings = repository.getAll();
        return FXCollections.observableList(
                ratings
                        .stream()
                        .map(dr -> new DistributorRatingModel(
                                dr.getOrganizer().getOrganizerUsername(),
                                dr.getDistributor().getDistributorUsername(),
                                dr.getRatingPercentage()
                        )).collect(Collectors.toList()));}

    public double getSummaryRating(String username_distributor) {  //for profile information
        double rating=0;int number_of_ratings=0;
        List<DistributorRating>ratings= repository.getAll();
        for(DistributorRating r:ratings)
        {
            if((r.getDistributor().getDistributorUsername().equals(username_distributor)))
            {
             rating = rating + r.getRatingPercentage();
             number_of_ratings++;
            }
        }
        rating = rating/number_of_ratings;
        return rating;}

    public double getRatingPercentage(String usernameDistributor) { //load update
        double p = 0;
        List <DistributorRating> all = repository.getAll();
        for(DistributorRating dr : all)
        {
            if(dr.getOrganizer().getOrganizerUsername().equals(service_organizer.getUsername()))
            {
                if(dr.getDistributor().getDistributorUsername().equals(usernameDistributor))
                {p = dr.getRatingPercentage();}}}
        return p;}

    public boolean CheckIfExists(DistributorRatingModel dr) { // before insert
        List<DistributorRating>ratings= DistributorRatingRepository.getInstance().getAll();
        for(DistributorRating r:ratings) {
            if((r.getDistributor().getDistributorUsername().equals(dr.getDistributor_username())&&(r.getOrganizer().getOrganizerUsername().equals(dr.getOrganizer_username()))))
            {return false;}}

        return true;}

    public void SaveDistributorRating(DistributorRatingModel model) {
        DistributorRating dr = new DistributorRating();
        dr.setOrganizer(service_organizer.getOrganizerByUsername(model.getOrganizer_username()));
        dr.setDistributor(service_distributor.getDistributorByUsername(model.getDistributor_username()));
        dr.setRatingPercentage(model.getRating_percentage());
        repository.save(dr);}

    public boolean UpdateDistributorRating(DistributorRatingModel model) {
        List<DistributorRating> all = repository.getAll();
        for(DistributorRating r : all) {
            if(r.getOrganizer().getOrganizerUsername().equals(service_organizer.getUsername())) {
                if (r.getDistributor().getDistributorUsername().equals(model.getDistributor_username())) {
                    if ((model.getRating_percentage() >= 0) && (model.getRating_percentage() <= 100)) {
                        r.setRatingPercentage(model.getRating_percentage());
                        repository.update(r);
                    }
                    else {return false;}}}}
        return true;}

    public void DeleteDistributorRating(DistributorRatingModel model) {
        List<DistributorRating> all = DistributorRatingRepository.getInstance().getAll();
        for(DistributorRating r : all) {
            if(r.getOrganizer().getOrganizerUsername().equals(service_organizer.getUsername())) {
                if (r.getDistributor().getDistributorUsername().equals(model.getDistributor_username())) {
                    repository.delete(r);
    }}}}

    public void getDistributorRatingView(MouseEvent event){try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.RATE_DISTRIBUTOR)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
    catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getUpdateDeleteDistributorRatingView(MouseEvent event){try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.UPDATE_DELETE_RATE_DISTRIBUTOR)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
    catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}
}
