package bg.tu_varna.sit.ticket_centar.data.repositories;
import java.util.List;

public interface DAORepository<T> {
    void save(T obj);
    void update(T obj);
    void delete(T obj);
    List<T> getAll();
}
