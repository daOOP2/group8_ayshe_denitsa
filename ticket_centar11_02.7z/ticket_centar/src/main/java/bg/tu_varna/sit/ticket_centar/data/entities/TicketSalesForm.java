package bg.tu_varna.sit.ticket_centar.data.entities;
import javax.persistence.*;

@Table(name = "ticket_sales_forms")
@Entity
public class TicketSalesForm {

    @Column(name = "client_first_name", nullable = false)
    private String client_first_name;

    @Column(name = "client_last_name", nullable = false)
    private String client_last_name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id", nullable = false)
    private Event event;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "distributor_id", nullable = false)
    private Distributor distributor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "place_price_id", nullable = false)
    private PlacePrice place_price;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ticket_sales_form_id", nullable = false)
    private Long ticket_sales_form_id;

    @Column(name = "phone_number", nullable = false)
    private String phone_number;

    @Column(name = "sale_date", nullable = false)
    private String sale_date;

    public TicketSalesForm(){}

    public Long getTicketSalesFormId() {
        return ticket_sales_form_id;
    }
    public void setTicketSalesFormId(Long ticket_sales_form_id) {
        this.ticket_sales_form_id = ticket_sales_form_id;
    }

    public String getClientFirstName() {
        return client_first_name;
    }
    public void setClientFirstName(String client_first_name) {
        this.client_first_name = client_first_name;
    }

    public String getClientLastName() {
        return client_last_name;
    }
    public void setClientLastName(String client_last_name) {
        this.client_last_name = client_last_name;
    }

    public Event getEvent() {return event;}
    public void setEvent(Event event) {this.event = event;}

    public Distributor getDistributor() {return distributor;}
    public void setDistributor(Distributor distributor) {this.distributor = distributor;}

    public PlacePrice getPlacePrice() {return place_price;}
    public void setPlacePrice(PlacePrice place_price) {this.place_price = place_price;}

    public String getPhoneNumber() {return phone_number;}
    public void setPhoneNumber(String phone_number) {this.phone_number=phone_number;}

    public String getSaleDate() {return sale_date;}
    public void setSaleDate(String sale_date) {this.sale_date=sale_date;}

    @Override
    public String toString() {
        return "ticket_sales_form{" +
                ", sale_date='" + sale_date + '\'' +
                ", client_first_name='" + client_first_name + '\'' +
                ", client_last_name='" + client_last_name + '\'' +
                ", phone_number='" + phone_number + '\'' +
                ", ticket_sales_form_id=" + ticket_sales_form_id +
                ", event=" + event +
                ", distributor=" + distributor +
                ", place_price=" + place_price +
                '}';
    }
}
