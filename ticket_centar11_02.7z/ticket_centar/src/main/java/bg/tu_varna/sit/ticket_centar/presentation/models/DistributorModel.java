package bg.tu_varna.sit.ticket_centar.presentation.models;

public class DistributorModel {
    private  String distributor_first_name;
    private  String distributor_last_name;
    private  String distributor_username;
    private  String distributor_password;
    private  String distributor_email;
    private  String distributor_phone_number;
    private  String distributor_address;
    private  Double distributor_honorarium;
    private String admin_username;
    private  Long distributor_id;

    public DistributorModel(){
        distributor_first_name="";
        distributor_last_name="";
        distributor_username="";
        distributor_password="";
        distributor_email="";
        distributor_phone_number="";
        distributor_address="";
        distributor_honorarium=0.0;
        admin_username = "";
        distributor_id= 0L;
    }


    public DistributorModel(String distributor_first_name, String distributor_last_name, String distributor_username, String distributor_password, String distributor_email, String distributor_phone_number, String distributor_address, Double distributor_honorarium, Long distributor_id, String admin_username) {
        this.distributor_first_name=distributor_first_name;
        this.distributor_last_name=distributor_last_name;
        this.distributor_username=distributor_username;
        this.distributor_password=distributor_password;
        this.distributor_email=distributor_email;
        this.distributor_phone_number=distributor_phone_number;
        this.distributor_address=distributor_address;
        this.distributor_honorarium=distributor_honorarium;
        this.distributor_id= distributor_id;
        this.admin_username=admin_username;
    }

    public String getDistributor_first_name(){return distributor_first_name;}
    public void setDistributor_first_name(String distributor_first_name){this.distributor_first_name=distributor_first_name;}

    public String getDistributor_last_name(){return distributor_last_name;}
    public void setDistributor_last_name(String distributor_last_name){this.distributor_last_name=distributor_last_name;}

    public String getDistributor_username(){return distributor_username;}
    public void setDistributor_username(String distributor_username){this.distributor_username=distributor_username;}

    public String getDistributor_password(){return distributor_password;}
    public void setDistributor_password(String distributor_password){this.distributor_password=distributor_password;}

    public String getDistributor_email(){return distributor_email;}
    public void setDistributor_email(String distributor_email){this.distributor_email=distributor_email;}

    public String getDistributor_phone_number(){return distributor_phone_number;}
    public void setDistributor_phone_number(String distributor_phone_number){this.distributor_phone_number=distributor_phone_number;}

    public String getDistributor_address(){return distributor_address;}
    public void setDistributor_address(String distributor_address){this.distributor_address=distributor_address;}

    public double getDistributor_honorarium(){return distributor_honorarium;}
    public void setDistributor_honorarium(double distributor_honorarium){this.distributor_honorarium=distributor_honorarium;}

    public Long getDistributor_id(){return distributor_id;}
    public void setDistributor_id(Long distributor_id){this.distributor_id=distributor_id;}

    public String getAdmin_username(){return admin_username;}
    public void setAdmin_username(String admin_username){this.admin_username=admin_username;}

    @Override
    public String toString()
    {
        return  String.format("Name: %s  %s | Username: %s | Password: %s | E-mail: %s | Phone Number: %s | Address: %s | Honorarium: %s | ID: %s | Admin: %s", distributor_first_name, distributor_last_name, distributor_username, distributor_password, distributor_email, distributor_phone_number, distributor_address, distributor_honorarium, distributor_id, admin_username);
    }

}
