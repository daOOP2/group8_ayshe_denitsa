package bg.tu_varna.sit.ticket_centar.presentation.models;

public class AdministratorModel {
    private  String admin_first_name;
    private  String admin_last_name;
    private  String admin_username;
    private  String admin_password;
    private  String admin_email;
    private  String admin_phone_number;
    private  String admin_address;
    private  Long admin_id;

    public AdministratorModel(){
        admin_first_name="";
        admin_last_name="";
        admin_username="";
        admin_password="";
        admin_email="";
        admin_phone_number="";
        admin_address="";
        admin_id= 0L;

    }

    public AdministratorModel(String admin_first_name, String admin_last_name, String admin_username, String admin_password, String admin_email, String admin_phone_number, String admin_address, Long admin_id){
        this.admin_first_name=admin_first_name;
        this.admin_last_name=admin_last_name;
        this.admin_username=admin_username;
        this.admin_password=admin_password;
        this.admin_email=admin_email;
        this.admin_phone_number=admin_phone_number;
        this.admin_address=admin_address;
        this.admin_id= admin_id;
    }

    public String getAdmin_first_name(){return admin_first_name;}
    public void setAdmin_first_name(String admin_first_name){this.admin_first_name=admin_first_name;}

    public String getAdmin_last_name(){return admin_last_name;}
    public void setAdmin_last_name(String admin_last_name){this.admin_last_name=admin_last_name;}

    public String getAdmin_username(){return admin_username;}
    public void setAdmin_username(String admin_username){this.admin_username=admin_username;}

    public String getAdmin_password(){return admin_password;}
    public void setAdmin_password(String admin_password){this.admin_password=admin_password;}

    public String getAdmin_email(){return admin_email;}
    public void setAdmin_email(String admin_email){this.admin_email=admin_email;}

    public String getAdmin_phone_number(){return admin_phone_number;}
    public void setAdmin_phone_number(String admin_phone_number){this.admin_phone_number=admin_phone_number;}

    public String getAdmin_address(){return admin_address;}
    public void setAdmin_address(String admin_address){this.admin_address=admin_address;}

    public Long getAdmin_id(){return admin_id;}
    public void setAdmin_id(Long admin_id){this.admin_id=admin_id;}

    @Override
    public String toString() {
        return  String.format("%s | %s | %s | %s | %s | %s | %s | %s", admin_first_name, admin_last_name, admin_username, admin_password, admin_email, admin_phone_number, admin_address, admin_id);
    }

}
