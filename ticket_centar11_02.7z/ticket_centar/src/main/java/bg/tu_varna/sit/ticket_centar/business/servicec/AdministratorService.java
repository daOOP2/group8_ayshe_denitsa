package bg.tu_varna.sit.ticket_centar.business.servicec;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import bg.tu_varna.sit.ticket_centar.data.entities.Administrator;
import bg.tu_varna.sit.ticket_centar.data.repositories.AdministratorRepository;
import bg.tu_varna.sit.ticket_centar.presentation.models.AdministratorModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class AdministratorService {
    private String username;

    private final AdministratorRepository repository = AdministratorRepository.getInstance();

    public static AdministratorService getInstance() {return AdministratorService.AdministratorServiceHolder.INSTANCE;}

    private static class AdministratorServiceHolder { public static final AdministratorService INSTANCE = new AdministratorService();}

    public String getUsername(){return username;}

    public ObservableList<AdministratorModel> getAllAdministrators() {
        List<Administrator> administrators = repository.getAll();
        return FXCollections.observableList(
                administrators
                        .stream()
                        .map(a -> new AdministratorModel(
                                a.getAdminFirstName(),
                                a.getAdminLastName(),
                                a.getAdminUsername(),
                                a.getAdminPassword(),
                                a.getAdminEmail(),
                                a.getAdminPhoneNumber(),
                                a.getAdminAddress(),
                                a.getAdminId()
                        )).collect(Collectors.toList()));}

    public Administrator getAdminByUsername(String username){  //
        List<Administrator>admins= repository.getAll();
        Administrator admin = new Administrator();
        for(Administrator a : admins){
            if(a.getAdminUsername().equals(username)){admin=a;}}
        return admin;}

    public boolean LogInAdmin(String username, String password){
        boolean login=false;
        AdministratorModel admin = new AdministratorModel();
        admin.setAdmin_username(username);
        admin.setAdmin_password(password);
        this.username = username;
        ObservableList<AdministratorModel> allAdmins = getAllAdministrators();
        for(AdministratorModel a:allAdmins ) {
            if ((a.getAdmin_username().equals(admin.getAdmin_username())) && (a.getAdmin_password().equals(admin.getAdmin_password()))) {
                login = true; break;} }
        return login;}

    public void getAdminView(MouseEvent event){try{
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.ADMIN_MENU_VIEW)));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();}
            catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getLogInView(MouseEvent event){try{
            Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.LOG_IN_VIEW)));
            Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();}
            catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}
}
