package bg.tu_varna.sit.ticket_centar.presentation.controllers.LogInControllers;
import bg.tu_varna.sit.ticket_centar.business.servicec.AdministratorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import java.io.File;

public class LogInController implements EventHandler<MouseEvent> {

    private final AdministratorService admin_service = AdministratorService.getInstance();
    private final OrganizerService org_service = OrganizerService.getInstance();
    private final DistributorService dis_service = DistributorService.getInstance();

    @FXML private Button buttonAdmin, buttonOrganizer, buttonDistributor;

    @FXML private TextField textFieldUsername;

    @FXML private PasswordField passwordFieldPassword;

    @FXML private ImageView imageView;

    @FXML private void initialize() {buttonAdmin.setOnMouseClicked(this);
        buttonOrganizer.setOnMouseClicked(this);buttonDistributor.setOnMouseClicked(this);

        File file = new File("@../../../../../../../../login.jpg");
        Image image = new Image(file.toURI().toString());imageView.setImage(image);}

    @Override public void handle(MouseEvent event) {

        if (event.getSource() == buttonAdmin) {
            if(admin_service.LogInAdmin(textFieldUsername.getText(),passwordFieldPassword.getText())) {
              admin_service.getAdminView(event);}}
        else if (event.getSource() == buttonOrganizer) {
            if(org_service.LogInOrganizer(textFieldUsername.getText(),passwordFieldPassword.getText())) {
              org_service.getOrganizerMenuView(event);}}
        else if (event.getSource() == buttonDistributor) {
            if (dis_service.LogInDistributor(textFieldUsername.getText(),passwordFieldPassword.getText())) {
             dis_service.getDistributorMenuView(event);}}
    }
}
