package bg.tu_varna.sit.ticket_centar.business.servicec;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import bg.tu_varna.sit.ticket_centar.data.entities.Distributor;
import bg.tu_varna.sit.ticket_centar.data.repositories.DistributorRepository;
import bg.tu_varna.sit.ticket_centar.presentation.models.DistributorModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class DistributorService {
    private String username;
    private final DistributorRepository repository = DistributorRepository.getInstance();
    private final AdministratorService service_adm = AdministratorService.getInstance();

    public static DistributorService getInstance() { return DistributorService.DistributorServiceHolder.INSTANCE; }
    private static class DistributorServiceHolder { public static final DistributorService INSTANCE = new DistributorService(); }

    public void setUsername(String username){this.username= username;}
    public String getUsername () {return username;}

    public ObservableList<DistributorModel> getAllDistributors() {
        List<Distributor> distributors = repository.getAll();
        return FXCollections.observableList(
                distributors
                        .stream()
                        .map(d -> new DistributorModel(
                                d.getDistributorFirstName(),
                                d.getDistributorLastName(),
                                d.getDistributorUsername(),
                                d.getDistributorPassword(),
                                d.getDistributorEmail(),
                                d.getDistributorPhoneNumber(),
                                d.getDistributorAddress(),
                                d.getDistributorHonorarium(),
                                d.getDistributorId(),
                                d.getAdmin().getAdminUsername()
                        )).collect(Collectors.toList()));}

    public Distributor getDistributorByUsername(String username) {
        List<Distributor>distributors= repository.getAll();
        Distributor dtr = new Distributor();
        for(Distributor d : distributors) {
            if(d.getDistributorUsername().equals(username))
            { dtr=d;}}
        return dtr;}

    public DistributorModel getDistributorModelByID(Long ID) {  // load update
        DistributorModel drm = new DistributorModel();
        drm.setDistributor_id(ID);
        List<DistributorModel> distributors = getAllDistributors();
        for(DistributorModel dis:distributors)
        {
            if((dis.getDistributor_id().equals(drm.getDistributor_id())))
            {drm=dis;}
        }
        return drm;}

    public boolean LogInDistributor(String username, String password){ boolean login=false;
        DistributorModel distributor = new DistributorModel();
        distributor.setDistributor_username(username);
        distributor.setDistributor_password(password);
        this.username=username;
        ObservableList<DistributorModel> allDistributors = getAllDistributors();
        for(DistributorModel d:allDistributors ) {
            if ((d.getDistributor_username().equals(distributor.getDistributor_username())) && (d.getDistributor_password().equals(distributor.getDistributor_password()))) {
                login = true; break; } }
        return login; }

    public DistributorModel getDistributorInfo(String username) // load profile information
    {
        DistributorModel drm = new DistributorModel();
        drm.setDistributor_username(username);
        List<DistributorModel> distributors = getAllDistributors();
        for(DistributorModel dis:distributors)
        {
            if((dis.getDistributor_username().equals(drm.getDistributor_username())))
            {
                drm=dis;
            }
        }
        return drm;
    }

    public boolean checkInputData(DistributorModel model) //add distributor
    {
        if(model.getDistributor_phone_number().length()!=13){return false;}
        else if(model.getDistributor_honorarium()<0){return false;}
        else if((model.getDistributor_id()>9999)||(model.getDistributor_id()<1000)){return false;}
        return true;
    }

    public boolean CheckPhoneNumberIfExistsOrCorrect(DistributorModel model) // update
    {
        if(model.getDistributor_phone_number().length()!=13) { return false; }

        List <DistributorModel> all = getAllDistributors();
        for(DistributorModel d : all)
        {
            if(d.getDistributor_phone_number().equals(model.getDistributor_phone_number())&&(!d.getDistributor_id().equals(model.getDistributor_id()))) { return false; }
        }
        return true;
    }

    public boolean CheckEmailIfExists(DistributorModel model) // update
    {
        List<DistributorModel> all = getAllDistributors();
        for(DistributorModel o : all)
        {
            if((o.getDistributor_email().equals(model.getDistributor_email()))&&(!o.getDistributor_id().equals(model.getDistributor_id()))) { return false; }
        }
        return true;
    }

    public boolean SaveDistributor(DistributorModel model)
    {
        Distributor dtr = new Distributor();
        List<Distributor>distributors= DistributorRepository.getInstance().getAll();
        dtr.setDistributorFirstName(model.getDistributor_first_name());
        dtr.setDistributorLastName(model.getDistributor_last_name());
        dtr.setDistributorUsername(model.getDistributor_username());
        dtr.setDistributorPassword(model.getDistributor_password());
        dtr.setDistributorEmail(model.getDistributor_email());
        dtr.setDistributorPhoneNumber(model.getDistributor_phone_number());
        dtr.setDistributorAddress(model.getDistributor_address());
        dtr.setDistributorHonorarium(model.getDistributor_honorarium());
        dtr.setAdmin(service_adm.getAdminByUsername(model.getAdmin_username()));
        dtr.setDistributorId(model.getDistributor_id());

        for(Distributor dis:distributors){if((dis.getDistributorUsername().equals(dtr.getDistributorUsername()))||(dis.getDistributorPassword().equals(dtr.getDistributorPassword()))||(dis.getDistributorEmail().equals(dtr.getDistributorEmail()))||(dis.getDistributorPhoneNumber().equals(dtr.getDistributorPhoneNumber())))
            { return false; }}

        repository.save(dtr);
        return true;
    }

    public void UpdateDistributor(DistributorModel model) {
        List <Distributor> all = DistributorRepository.getInstance().getAll();
        for(Distributor d : all)
        {
            if(d.getDistributorId().equals(model.getDistributor_id())) {

                if(d.getAdmin().getAdminUsername().equals(service_adm.getUsername())) {
                    d.setDistributorEmail(model.getDistributor_email());
                    d.setDistributorPhoneNumber(model.getDistributor_phone_number());
                    d.setDistributorAddress(model.getDistributor_address());
                    d.setDistributorHonorarium(model.getDistributor_honorarium());
                    repository.update(d);}}}}

    public void getDistributorMenuView(MouseEvent event){try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.DISTRIBUTOR_MENU_VIEW)));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
        catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getNewDistributorView(MouseEvent event){try{
            Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.NEW_DISTRIBUTOR_VIEW)));
            Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();}
            catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getProfileDistributorsView(MouseEvent event){try{
        Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.DISTRIBUTORS_PROFILE_VIEW)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
        catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getUpdateDistributorView(MouseEvent event){try{
        Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.UPDATE_DISTRIBUTOR_VIEW)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
        catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getDistributorEventsView(MouseEvent event){ try{
        Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.DISTRIBUTOR_EVENTS)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
        catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getDistributorNotificationsView(MouseEvent event){ try{
        Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.DISTRIBUTOR_NOTIFICATIONS)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
        catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}
}

