package bg.tu_varna.sit.ticket_centar.presentation.models;

public class EventDistributorModel{
 private String distributor_username;
 private String event_name;
 private String date;

    public EventDistributorModel(){
        this.distributor_username="";
        this.event_name= "";
        this.date="";
    }

    public EventDistributorModel(String distributor_username, String event_name, String date){
        this.distributor_username=distributor_username;
        this.event_name=event_name;
        this.date=date;
    }

    public String getDistributor_username() {return distributor_username;}
    public void setDistributor_username(String distributor_username){this.distributor_username=distributor_username;}

    public String getEvent_name(){return event_name;}
    public void setEvent_name(String event_name){this.event_name=event_name;}

    public String getDate(){return date;}
    public void setDate(String date){this.date=date;}

    @Override
    public String toString() {
        return  String.format("%s | %s ", distributor_username, event_name);
    }
}
