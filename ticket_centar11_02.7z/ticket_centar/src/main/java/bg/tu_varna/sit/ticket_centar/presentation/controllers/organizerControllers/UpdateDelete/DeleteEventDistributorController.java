package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.UpdateDelete;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventDistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventDistributorModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class DeleteEventDistributorController  implements EventHandler<MouseEvent> {

    private final OrganizerService service_o = OrganizerService.getInstance();
    private final EventDistributorService service_ed = EventDistributorService.getInstance();

    @FXML
    private Button delete, menu;

    @FXML private TextField result, eventName, usernameDistributor;

    @FXML private void initialize() { result.setEditable(false);
        delete.setOnMouseClicked(this); menu.setOnMouseClicked(this); }

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == delete) {

            EventDistributorModel ed = new EventDistributorModel();
            ed.setDistributor_username(usernameDistributor.getText());
            ed.setEvent_name(eventName.getText());
            service_ed.DeleteEventDistributor(ed);

        }
        else if (event.getSource() == menu) { service_o.getOrganizerMenuView(event);}
    }
}