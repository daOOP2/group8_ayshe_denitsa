package bg.tu_varna.sit.ticket_centar.presentation.models;

public class DistributorRatingModel {

    private String organizer_username;
    private String distributor_username;
    private double rating_percentage;

    public DistributorRatingModel(){
        this.organizer_username = "";
        this.distributor_username = "";
        rating_percentage = 0.0;
    }

    public DistributorRatingModel(String organizer_username, String distributor_username, double rating_percentage){
        this.organizer_username = organizer_username;
        this.distributor_username = distributor_username;
        this.rating_percentage = rating_percentage;
    }

    public String getOrganizer_username(){return organizer_username;}
    public void setOrganizer_username(String organizer_username){this.organizer_username=organizer_username;}

    public String getDistributor_username(){return distributor_username;}
    public void setDistributor_username(String distributor_username){this.distributor_username=distributor_username;}

    public double getRating_percentage(){return rating_percentage;}
    public void setRating_percentage(double rating_percentage){this.rating_percentage=rating_percentage;}


    @Override
    public String toString()
    {
        return  String.format("%s | %s | %s", organizer_username, distributor_username, rating_percentage);
    }
}

