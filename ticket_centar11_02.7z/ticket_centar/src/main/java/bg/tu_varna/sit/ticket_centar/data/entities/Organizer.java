package bg.tu_varna.sit.ticket_centar.data.entities;
import javax.persistence.*;
import java.util.Set;

@Table(name = "organizers")
@Entity
public class Organizer {

    @Column(name = "organizer_first_name", nullable = false)
    private String organizer_first_name;

    @Column(name = "organizer_last_name", nullable = false)
    private String organizer_last_name;

    @Column(name = "organizer_username", nullable = false, unique = true)
    private String organizer_username;

    @Column(name = "organizer_password", nullable = false, unique = true)
    private String organizer_password;

    @Column(name = "organizer_email", nullable = false, unique = true)
    private String organizer_email;

    @Column(name = "organizer_phone_number", nullable = false, unique = true)
    private String organizer_phone_number;

    @Column(name = "organizer_address", nullable = false)
    private String organizer_address;

    @Column(name = "organizer_honorarium", nullable = false)
    private Double organizer_honorarium;

    @Id
    @Column(name = "organizer_id", nullable = false, unique = true)
    private Long organizer_id;

    @OneToMany(mappedBy = "organizer", fetch = FetchType.LAZY)
    private Set<Event> eventSet;

    @OneToMany(mappedBy = "organizer", fetch = FetchType.LAZY)
    private Set<DistributorRating> distributorRatingSet;

     @ManyToOne(fetch = FetchType.LAZY)
     @JoinColumn(name = "admin_id", nullable = false)
     private Administrator admin;

     public Organizer(){}

    public Long getOrganizerId() {
        return organizer_id;
    }
    public void setOrganizerId(Long organizer_id) {
        this.organizer_id = organizer_id;
    }

    public String getOrganizerFirstName() {
        return organizer_first_name;
    }
    public void setOrganizerFirstName(String organizer_first_name) {this.organizer_first_name = organizer_first_name;}

    public String getOrganizerLastName() {return organizer_last_name;}
    public void setOrganizerLastName(String organizer_last_name) {
        this.organizer_last_name = organizer_last_name;
    }

    public String getOrganizerUsername() {
        return organizer_username;
    }
    public void setOrganizerUsername(String organizer_username) {
        this.organizer_username = organizer_username;
    }

    public String getOrganizerPassword() {
        return organizer_password;
    }
    public void setOrganizerPassword(String organizer_password) {
        this.organizer_password = organizer_password;
    }

    public String getOrganizerEmail() {
        return organizer_email;
    }
    public void setOrganizerEmail(String organizer_email) {
        this.organizer_email = organizer_email;
    }

    public String getOrganizerPhoneNumber() {
        return organizer_phone_number;
    }
    public void setOrganizerPhoneNumber(String organizer_phone_number) {this.organizer_phone_number = organizer_phone_number;}

    public String getOrganizerAddress() {
        return organizer_address;
    }
    public void setOrganizerAddress(String organizer_address) {
        this.organizer_address = organizer_address;
    }

    public Double getOrganizerHonorarium(){return organizer_honorarium;}
    public void setOrganizerHonorarium(Double organizer_honorarium){this.organizer_honorarium=organizer_honorarium;}

     public Administrator getAdmin() {return admin;}
     public void setAdmin(Administrator admin) {this.admin = admin;}

    public Set<Event> getEventSet() {return eventSet;}
    public void setEventSet(Set<Event> eventSet) {this.eventSet = eventSet;}

    public Set<DistributorRating> getDistributorRatingSet() {return distributorRatingSet;}
    public void setDistributorRatingSet(Set<DistributorRating> distributorRatingSet) {this.distributorRatingSet = distributorRatingSet;}

    @Override
    public String toString() {
        return "distributor{" +
                "organizer_first_name='" + organizer_first_name +'\''+
                ", organizer_last_name='" + organizer_last_name + '\'' +
                ", organizer_username='" + organizer_username + '\'' +
                ", organizer_password='" + organizer_password + '\'' +
                ", organizer_email='" + organizer_email + '\'' +
                ", organizer_phone_number='" + organizer_phone_number + '\'' +
                ", organizer_address='" + organizer_address + '\'' +
                ", organizer_honorarium=" + organizer_honorarium +
                ", organizer_id=" + organizer_id +
                ", admin=" + admin +
                ", eventSet=" + eventSet +
                ", distributorRatingSet=" + distributorRatingSet +
                '}';
    }

}

