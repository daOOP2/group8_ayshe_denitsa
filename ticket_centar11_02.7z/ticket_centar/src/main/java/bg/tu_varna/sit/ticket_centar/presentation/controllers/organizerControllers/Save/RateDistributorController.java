package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Save;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorRatingService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.DistributorRatingModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class RateDistributorController implements EventHandler<MouseEvent> {

    private final DistributorRatingService service_dr = DistributorRatingService.getInstance();
    private final OrganizerService service_org = OrganizerService.getInstance();

    @FXML private Button buttonMenu , buttonSave;

    @FXML private TextField tfResult, tfDistributorUsername, tfRatingPercentage;

    @FXML private void initialize()
    {
        tfResult.setEditable(false);
        buttonSave.setOnMouseClicked(this);
        buttonMenu.setOnMouseClicked(this);
    }

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == buttonSave) {

            if((Double.parseDouble(tfRatingPercentage.getText())>100)||(Double.parseDouble(tfRatingPercentage.getText())<0))
            {
                tfResult.setText("Incorrect Value For Rating Percentage!");
            }
            else {
                DistributorRatingModel drm = new DistributorRatingModel(service_org.getUsername(), tfDistributorUsername.getText().toLowerCase(), Double.parseDouble(tfRatingPercentage.getText()));
                boolean result = service_dr.CheckIfExists(drm);
                if (result) {
                    service_dr.SaveDistributorRating(drm);
                    tfResult.setText("");
                } else {
                    tfResult.setText("Rating Already Exists!");
                }
            }



        }
        else if (event.getSource() == buttonMenu)
        {
            service_org.getOrganizerMenuView(event);
        }
    }
}
