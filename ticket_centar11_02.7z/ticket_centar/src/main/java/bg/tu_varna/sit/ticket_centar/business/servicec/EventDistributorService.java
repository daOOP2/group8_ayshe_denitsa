package bg.tu_varna.sit.ticket_centar.business.servicec;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import bg.tu_varna.sit.ticket_centar.data.entities.EventDistributor;
import bg.tu_varna.sit.ticket_centar.data.entities.TicketSalesForm;
import bg.tu_varna.sit.ticket_centar.data.repositories.EventDistributorRepository;
import bg.tu_varna.sit.ticket_centar.data.repositories.TicketSalesFormRepository;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventDistributorModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.TicketSalesFormModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class EventDistributorService {

    private final EventDistributorRepository repository = EventDistributorRepository.getInstance();
    private final DistributorService service_distributor = DistributorService.getInstance();
    private final EventService service_event = EventService.getInstance();
    private final OrganizerService service_org = OrganizerService.getInstance();

    public static EventDistributorService getInstance() {

        return EventDistributorService.EventDistributorServiceHolder.INSTANCE;
    }

    private static class EventDistributorServiceHolder {
        public static final EventDistributorService INSTANCE = new EventDistributorService();
    }

    public ObservableList<EventDistributorModel> getAllEventDistributors() {
        List<EventDistributor> eventDistributors = repository.getAll();

        return FXCollections.observableList(
                eventDistributors
                        .stream()
                        .map(ed -> new EventDistributorModel(
                                ed.getDistributor().getDistributorUsername(),
                                ed.getEvent().getEventName(),
                                ed.getDate()
                        )).collect(Collectors.toList()));}

    public ObservableList<String> getEventsByDistributor(String username_distributor, LocalDate from, LocalDate to) { // load events data from date to date
        String event=""; int sold=0;
        ObservableList<String> list =FXCollections.observableArrayList();
        List<EventDistributorModel>eventDistributors=getAllEventDistributors();
        List<TicketSalesFormModel>ticketSalesForms=TicketSalesFormService.getInstance().getAllForms();
        List<EventModel>events = EventService.getInstance().getAllEvents();

        for(EventDistributorModel e:eventDistributors){
            if(e.getDistributor_username().equals(username_distributor)) {
            for(EventModel m : events){
                if(m.getEvent_name().equals(e.getEvent_name())){
                    if((LocalDate.parse(m.getEvent_date()).isAfter(from))&&(LocalDate.parse(m.getEvent_date()).isBefore(to))) {
                        for (TicketSalesFormModel t : ticketSalesForms) {
                            if ((t.getDistributor_username().equals(username_distributor)) && (t.getEvent_name().equals(m.getEvent_name()))) {
                                sold++;
                            }
                        }
                        event = "Distributor: " + e.getDistributor_username() + " Event: " + m.getEvent_name() + " "+m.getEvent_date()+ " Number Of Tickets:"+m.getEvent_number_of_places() + " Sold Tickets: " + sold;
                        sold = 0;
                        list.add(event);}}}}}
        return list;}

    public ObservableList<String> getLastAddedEvents(String distributor_username){  // load events if I am a distributor for period
        ObservableList<String> list =FXCollections.observableArrayList();
        List<EventDistributorModel>eventDistributors=getAllEventDistributors();
        List<EventModel>events=service_event.getAllEvents();
        for(EventModel e : events) {
                for(EventDistributorModel em : eventDistributors)
                {
                    if((em.getEvent_name().equals(e.getEvent_name()))&&(em.getDistributor_username().equals(distributor_username)))
                    {
                        if ((LocalDate.parse(em.getDate()).getMonthValue() == LocalDate.now().getMonthValue())&&((LocalDate.parse(em.getDate()).getYear())==(LocalDate.now().getYear()))) {
                            String event = "Added: "+ em.getDate() +" Event: " + e.getEvent_name() + " Date: " + e.getEvent_date() + " Number Of Places: " + e.getEvent_number_of_places() + " Sold: " + TicketSalesFormService.getInstance().getSoldTicketsForEvent(e.getEvent_name());
                            list.add(event);
                        }}}}
        return list;}

    public boolean SaveEventDistributor(EventDistributorModel model){
        List<EventDistributor>eventDistributors= EventDistributorRepository.getInstance().getAll();
        EventDistributor ed = new EventDistributor();
        ed.setDistributor(service_distributor.getDistributorByUsername(model.getDistributor_username()));
        ed.setEvent(service_event.getEventByName(model.getEvent_name()));
        ed.setDate(model.getDate());

        if(!(ed.getEvent().getOrganizer().getOrganizerUsername().equals(service_org.getUsername()))){return false;}

        for(EventDistributor r:eventDistributors) {
            if((r.getDistributor().getDistributorUsername().equals(ed.getDistributor().getDistributorUsername()))&&(r.getEvent().getEventName().equals(ed.getEvent().getEventName())))
            {return false;}
        }
        repository.save(ed);
        return true;}

    public void DeleteEventDistributor(EventDistributorModel model){
        List<EventDistributor>all = EventDistributorRepository.getInstance().getAll();
        for(EventDistributor e : all)
        {
            if(e.getEvent().getOrganizer().getOrganizerUsername().equals(service_org.getUsername())) {
                if ((e.getEvent().getEventName().equals(model.getEvent_name()))&&(e.getDistributor().getDistributorUsername().equals(model.getDistributor_username())))
                {
                        repository.delete(e);
                }}}
    }

    public void getEventDistributorsView(MouseEvent event){try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.EVENT_DISTRIBUTOR)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
    catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getDeleteEventDistributorsView(MouseEvent event){try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.DELETE_EVENT_DISTRIBUTOR)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
    catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}
}

