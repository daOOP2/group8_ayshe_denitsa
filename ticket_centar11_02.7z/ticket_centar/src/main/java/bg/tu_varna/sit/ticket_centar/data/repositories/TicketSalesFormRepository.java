package bg.tu_varna.sit.ticket_centar.data.repositories;
import bg.tu_varna.sit.ticket_centar.data.access.Connection;
import bg.tu_varna.sit.ticket_centar.data.entities.TicketSalesForm;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.LinkedList;
import java.util.List;

public class TicketSalesFormRepository implements DAORepository<TicketSalesForm> {

    private static final Logger log = Logger.getLogger(TicketSalesForm.class);

    public static TicketSalesFormRepository getInstance() { return TicketSalesFormRepository.TicketSalesFormRepositoryHolder.INSTANCE;}

    private static class TicketSalesFormRepositoryHolder {
        public static final TicketSalesFormRepository INSTANCE = new TicketSalesFormRepository();
    }

    @Override
    public void save(TicketSalesForm ticket_sales_form) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(ticket_sales_form);
            log.info("Ticket Sales Form saved successfully");
        } catch (Exception ex) {
            log.error("Ticket Sales Form save error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void update(TicketSalesForm ticket_sales_form) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            TicketSalesForm t = session.get(TicketSalesForm.class, ticket_sales_form.getTicketSalesFormId());
            t.setPhoneNumber(ticket_sales_form.getPhoneNumber());
            session.update(t);
            log.info("Ticket Sales Form updated successfully");
        } catch (Exception ex) {
            log.error("Ticket Sales Form update error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void delete(TicketSalesForm ticket_sales_form) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            TicketSalesForm t = session.get(TicketSalesForm.class, ticket_sales_form.getTicketSalesFormId());
            session.delete(t);
            log.info("Ticket Sales Form deleted successfully");
        } catch (Exception ex) {
            log.error("Ticket Sales Form delete error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public List<TicketSalesForm> getAll() {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        List<TicketSalesForm> TicketSalesForm = new LinkedList<>();
        try {
            String jpql = "SELECT t FROM TicketSalesForm  t";
            TicketSalesForm.addAll(session.createQuery(jpql, TicketSalesForm.class).getResultList());
            log.info("Get all Ticket Sales Forms");
        } catch (Exception ex) {
            log.error("Get Ticket Sales Forms error: " + ex.getMessage());
        } finally {
            transaction.commit();
           // Connection.openSessionClose();
        }

        return TicketSalesForm;
    }
}


