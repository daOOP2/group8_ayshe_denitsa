package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.OrganizerMenu;
import bg.tu_varna.sit.ticket_centar.business.servicec.*;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;

public class OrganizerMenuController implements EventHandler<MouseEvent> {

    private final EventService service_e = EventService.getInstance();
    private final EventDistributorService service_ed = EventDistributorService.getInstance();
    private final OrganizerService service_o = OrganizerService.getInstance();
    private final AdministratorService service_a = AdministratorService.getInstance();
    private final DistributorRatingService service_r = DistributorRatingService.getInstance();
    private final PlacePriceService service_pp = PlacePriceService.getInstance();
    private final EventPlacesService service_ep = EventPlacesService.getInstance();

    @FXML private Button  newEvent,rate,events, notifications, logOut, eventDistributor, placePrices,eventPlaces, updateEvent, deleteEventDistributors, updateDeleteEventPlaces, updateDeletePlacePrices, updateDeleteDistributorRating;

    @FXML private void initialize() {
        newEvent.setOnMouseClicked(this); rate.setOnMouseClicked(this);
        events.setOnMouseClicked(this); notifications.setOnMouseClicked(this);
        logOut.setOnMouseClicked(this); eventDistributor.setOnMouseClicked(this);
        placePrices.setOnMouseClicked(this); eventPlaces.setOnMouseClicked(this);
        updateDeletePlacePrices.setOnMouseClicked(this); updateDeleteEventPlaces.setOnMouseClicked(this);
        updateDeleteDistributorRating.setOnMouseClicked(this); updateEvent.setOnMouseClicked(this);
        deleteEventDistributors.setOnMouseClicked(this);}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == newEvent) { service_e.getNewEventView(event);}
        else if (event.getSource() == events) { service_o.getOrganizerEventsView(event);}
        else if(event.getSource()==updateEvent){service_e.getUpdateEventView(event);}
        else if (event.getSource() == notifications) { service_o.getOrganizerNotificationsView(event);}
        else if (event.getSource() == logOut) { service_a.getLogInView(event);}
        else if (event.getSource() == rate) { service_r.getDistributorRatingView(event); }
        else if (event.getSource() == eventDistributor) { service_ed.getEventDistributorsView(event);}
        else if (event.getSource() == placePrices) { service_pp.getPlacePriceView(event);}
        else if(event.getSource()==updateDeletePlacePrices){service_pp.getUpdateDeletePlacePriceView(event);}
        else if (event.getSource() == eventPlaces) { service_ep.getEventPlacesView(event);}
        else if (event.getSource() == updateDeleteEventPlaces) { service_ep.getUpdateDeleteEventPlacesView(event);}
        else if (event.getSource() == updateDeleteDistributorRating) { service_r.getUpdateDeleteDistributorRatingView(event);}
        else if(event.getSource()==deleteEventDistributors){service_ed.getDeleteEventDistributorsView(event);}

    }
}




