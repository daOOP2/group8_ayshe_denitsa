package bg.tu_varna.sit.ticket_centar.data.entities;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Set;

@Table(name = "administrators")
@Entity
public class Administrator implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "admin_first_name", nullable = false)
    private String admin_first_name;

    @Column(name = "admin_last_name", nullable = false)
    private String admin_last_name;

    @Column(name = "admin_username", nullable = false)
    private String admin_username;

    @Column(name = "admin_password", nullable = false)
    private String admin_password;

    @Column(name = "admin_email", nullable = false)
    private String admin_email;

    @Column(name = "admin_phone_number", nullable = false)
    private String admin_phone_number;

    @Column(name = "admin_address", nullable = false)
    private String admin_address;

    @Id
    @Column(name = "admin_id", nullable = false)
    private Long admin_id;

    @OneToMany(mappedBy = "admin", fetch = FetchType.LAZY)
    private Set<Distributor> distributorSet;

    @OneToMany(mappedBy = "admin", fetch = FetchType.LAZY)
    private Set<Organizer> organizerSet;

    public Administrator(){}

    public Long getAdminId() {
        return admin_id;
    }
    public void setAdminId(Long admin_id) {
        this.admin_id = admin_id;
    }

    public String getAdminFirstName() {
        return admin_first_name;
    }
    public void setAdminFirstName(String admin_first_name) {
        this.admin_first_name = admin_first_name;
    }

    public String getAdminLastName() {
        return admin_last_name;
    }
    public void setAdminLastName(String admin_last_name) {
        this.admin_last_name = admin_last_name;
    }

    public String getAdminUsername() {
        return admin_username;
    }
    public void setAdminUsername(String admin_username) {
        this.admin_username = admin_username;
    }

    public String getAdminPassword() {
        return admin_password;
    }
    public void setAdminPassword(String admin_password) {
        this.admin_password = admin_password;
    }

    public String getAdminEmail() {
        return admin_email;
    }
    public void setAdminEmail(String admin_email) {
        this.admin_email = admin_email;
    }

    public String getAdminPhoneNumber() {
        return admin_phone_number;
    }
    public void setAdminPhoneNumber(String admin_phone_number) {
        this.admin_phone_number = admin_phone_number;
    }

    public String getAdminAddress() {
        return admin_address;
    }
    public void setAdminAddress(String admin_address) {
        this.admin_address = admin_address;
    }

    public Set<Distributor> getDistributorSet() { return distributorSet; }
    public void setDistributorSet(Set<Distributor> distributorSet) { this.distributorSet = distributorSet;}

    public Set<Organizer> getOrganizerSet() { return organizerSet; }
    public void setOrganizerSet(Set<Organizer> organizerSet) { this.organizerSet = organizerSet;}

    @Override
    public String toString() {
        return "administrator{" +
                "admin_first_name='" + admin_first_name +'\''+
                ", admin_last_name='" + admin_last_name + '\'' +
                ", admin_username='" + admin_username + '\'' +
                ", admin_password='" + admin_password + '\'' +
                ", admin_email='" + admin_email + '\'' +
                ", admin_phone_number='" + admin_phone_number + '\'' +
                ", admin_address='" + admin_address + '\'' +
                ", admin_id=" + admin_id +
                ", distributorSet=" + distributorSet +
                ", organizerSet=" + organizerSet +
                '}';
    }

}
