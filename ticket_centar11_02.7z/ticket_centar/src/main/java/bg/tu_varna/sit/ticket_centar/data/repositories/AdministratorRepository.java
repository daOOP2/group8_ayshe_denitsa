package bg.tu_varna.sit.ticket_centar.data.repositories;
import bg.tu_varna.sit.ticket_centar.data.access.Connection;
import bg.tu_varna.sit.ticket_centar.data.entities.Administrator;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public class AdministratorRepository implements DAORepository<Administrator> {

    private static final Logger log = Logger.getLogger(AdministratorRepository.class);

    public static AdministratorRepository getInstance() { return AdministratorRepository.AdministratorRepositoryHolder.INSTANCE;}

    private static class AdministratorRepositoryHolder {
        public static final AdministratorRepository INSTANCE = new AdministratorRepository();
    }

    @Override
    public void save(Administrator admin) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(admin);
            log.info("Administrator saved successfully");
        } catch (Exception ex) {
            log.error("Administrator save error" + ex.getMessage());
        } finally {
            transaction.commit();

        }
    }

    @Override
    public void update(Administrator admin) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.update(admin);
            log.info("Administrator updated successfully");
        } catch (Exception ex) {
            log.error("Administrator update error" + ex.getMessage());
        } finally {
            transaction.commit();

        }
    }

    @Override
    public void delete(Administrator admin) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.delete(admin);
            log.info("Administrator deleted successfully");
        } catch (Exception ex) {
            log.error("Administrator delete error" + ex.getMessage());
        } finally {
            transaction.commit();
        }

    }

    @Override
    public List<Administrator> getAll() {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        List<Administrator> Administrator = new LinkedList<>();
        try {
            String jpql = "SELECT a FROM Administrator a";
            Administrator.addAll(session.createQuery(jpql, Administrator.class).getResultList());
            log.info("Get all admins");
        } catch (Exception ex) {
            log.error("Get admin error: " + ex.getMessage());
        } finally {
            transaction.commit();
           // Connection.openSessionClose();
        }

        return Administrator;
    }

}

