package bg.tu_varna.sit.ticket_centar.presentation.models;

public class PlacePriceModel {
    private String place_type;
    private double place_price;

    public PlacePriceModel()
    {
        this.place_type="";
        this.place_price=0.0;
    }

    public PlacePriceModel(String place_type, double place_price){
        this.place_type=place_type;
        this.place_price=place_price;
    }

    public String getPlace_type(){return place_type;}
    public double getPlace_price(){return place_price;}

    public void setPlace_type(String place_type){this.place_type=place_type;}
    public void setPlace_price(double place_price){this.place_price=place_price;}

    @Override
    public String toString() {
        return  String.format("%s | %s", place_type, place_price);
    }
}
