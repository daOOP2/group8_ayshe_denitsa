package bg.tu_varna.sit.ticket_centar.presentation.models;


public class TicketSalesFormModel {

    private String client_first_name;
    private String client_last_name;
    private String phone_number;
    private String event_name;
    private String place_type;
    private String distributor_username;
    private String sale_date;

    public TicketSalesFormModel(String client_first_name, String client_last_name, String phone_number, String event_name, String place_type, String distributor_username, String sale_date){
        this.client_first_name=client_first_name;
        this.client_last_name=client_last_name;
        this.phone_number=phone_number;
        this.event_name=event_name;
        this.place_type=place_type;
        this.distributor_username=distributor_username;
        this.sale_date=sale_date;
    }

    public TicketSalesFormModel(){
        this.client_first_name="";
        this.client_last_name="";
        this.phone_number="";
        this.event_name= "";
        this.place_type="";
        this.distributor_username="";
        this.sale_date="";
    }


    public String getClient_first_name(){return client_first_name;}
    public void setClient_first_name(String client_first_name){this.client_first_name=client_first_name;}

    public String getClient_last_name(){return client_last_name;}
    public void setClient_last_name(String client_last_name){this.client_last_name=client_last_name;}

    public String getPhone_number(){return phone_number;}
    public void setPhone_number(String phone_number){this.phone_number=phone_number;}

    public String getEvent_name(){return event_name;}
    public void setEvent_name(String event_name){this.event_name=event_name;}

    public String getPlace_type(){return place_type;}
    public void setPlace_type(String place_type){this.place_type=place_type;}

    public String getDistributor_username(){return distributor_username;}
    public void setDistributor_username(String distributor_username){this.distributor_username=distributor_username;}

    public String getSale_date(){return sale_date;}
    public void setSale_date(String sale_date){this.sale_date=sale_date;}

    @Override
    public String toString() {
        return  String.format("%s | %s | %s | %s | %s | %s | %s ", sale_date, client_first_name, client_last_name, phone_number, event_name, place_type, distributor_username);
    }

}
