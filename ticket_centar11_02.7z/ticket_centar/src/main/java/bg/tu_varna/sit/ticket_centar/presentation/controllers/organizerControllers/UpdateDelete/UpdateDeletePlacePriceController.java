package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.UpdateDelete;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.business.servicec.PlacePriceService;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class UpdateDeletePlacePriceController  implements EventHandler<MouseEvent> {

    private final OrganizerService service_o = OrganizerService.getInstance();
    private final PlacePriceService service_pp = PlacePriceService.getInstance();

    @FXML
    private Button delete, menu, update, loadPrice;

    @FXML private TextField result, type, price, new_price;

    @FXML private void initialize() {
        menu.setOnMouseClicked(this); delete.setOnMouseClicked(this);
        update.setOnMouseClicked(this); loadPrice.setOnMouseClicked(this);
        result.setEditable(false); price.setEditable(false);
    }

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == delete)
        {
            service_pp.DeletePlacePrice(type.getText());
        }
        else if(event.getSource()==update)
        {
            if(!(service_pp.UpdatePlacePrice(type.getText(),Double.parseDouble(new_price.getText()))))
            {
                result.setText("Incorrect Data!");
            }
        }
        else if(event.getSource()==loadPrice)
        {
            price.setText(String.valueOf(service_pp.loadPrice(type.getText())));
        }
        else if (event.getSource() == menu)
        {
            service_o.getOrganizerMenuView(event);
        }
    }
}
