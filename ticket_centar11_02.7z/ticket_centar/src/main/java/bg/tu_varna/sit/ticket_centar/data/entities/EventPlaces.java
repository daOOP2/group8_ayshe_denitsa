package bg.tu_varna.sit.ticket_centar.data.entities;
import javax.persistence.*;


@Table(name = "event_places")
@Entity
public class EventPlaces {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_places_id", nullable = false)
    private Long event_places_id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id", nullable = false)
    private Event event;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "place_price_id", nullable = false)
    private PlacePrice place_price;

    @Column(name = "number_of_tickets", nullable = false)
    private int number_of_tickets;


    public EventPlaces(){}

    public Long getEventPlacesId() {
        return event_places_id;
    }
    public void setEventPlacesId(Long event_places_id) {this.event_places_id = event_places_id;}

    public int getNumberOfTickets() {
        return number_of_tickets;
    }
    public void setNumberOfTickets(int number_of_tickets) {this.number_of_tickets = number_of_tickets;}

    public Event getEvent() {return event;}
    public void setEvent(Event event) {this.event = event;}

    public PlacePrice getPlacePrice() {return place_price;}
    public void setPlacePrice(PlacePrice place_price) {this.place_price = place_price;}

    @Override
    public String toString() {
        return "event_places{" +
                "number_of_tickets =" + number_of_tickets +
                ", event =" + event +
                ", place_price =" + place_price +
                ", event_places_id =" + event_places_id +
                '}';
    }
}
