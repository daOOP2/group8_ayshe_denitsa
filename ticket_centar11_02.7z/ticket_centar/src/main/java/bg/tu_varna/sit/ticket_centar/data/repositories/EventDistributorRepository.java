package bg.tu_varna.sit.ticket_centar.data.repositories;
import bg.tu_varna.sit.ticket_centar.data.access.Connection;
import bg.tu_varna.sit.ticket_centar.data.entities.EventDistributor;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.LinkedList;
import java.util.List;

public class EventDistributorRepository implements DAORepository<EventDistributor> {

private static final Logger log = Logger.getLogger(EventDistributorRepository.class);

public static EventDistributorRepository getInstance() { return EventDistributorRepository.EventDistributorRepositoryHolder.INSTANCE;}

private static class EventDistributorRepositoryHolder {
    public static final EventDistributorRepository INSTANCE = new EventDistributorRepository();
}

    @Override
    public void save(EventDistributor event_distributor) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(event_distributor);
            log.info("Event Distributor saved successfully");
        } catch (Exception ex) {
            log.error("Event Distributor save error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void update(EventDistributor event_distributor) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.update(event_distributor);
            log.info("Event Distributor updated successfully");
        } catch (Exception ex) {
            log.error("Event Distributor update error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void delete(EventDistributor event_distributor) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.delete(event_distributor);
            log.info("Event Distributor deleted successfully");
        } catch (Exception ex) {
            log.error("Event Distributor delete error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public List<EventDistributor> getAll() {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        List<EventDistributor> EventDistributor = new LinkedList<>();
        try {
           String jpql = "SELECT ed FROM EventDistributor ed";
            EventDistributor.addAll(session.createQuery(jpql, EventDistributor.class).getResultList());
            log.info("Get all Events Distributors");
        } catch (Exception ex) {
            log.error("Get Event Distributor error: " + ex.getMessage());
        } finally {
            transaction.commit();
           // Connection.openSessionClose();
        }

        return EventDistributor;
    }
}
