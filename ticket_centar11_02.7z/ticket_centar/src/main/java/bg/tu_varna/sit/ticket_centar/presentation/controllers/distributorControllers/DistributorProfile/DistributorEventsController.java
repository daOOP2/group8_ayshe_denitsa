package bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.DistributorProfile;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorRatingService;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventDistributorService;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.time.LocalDate;
import java.util.Date;

public class DistributorEventsController implements EventHandler<MouseEvent> {

    private final DistributorService service_d = DistributorService.getInstance();
    private final DistributorRatingService service_dr = DistributorRatingService.getInstance();
    private final EventDistributorService service_evd = EventDistributorService.getInstance();

    @FXML private Button buttonShow, buttonMenu;

    @FXML private TextField main_info, rating;

    @FXML private ListView<String> eventsList;

    @FXML private DatePicker from, to;

    @FXML private void initialize() {
        buttonShow.setOnMouseClicked(this); buttonMenu.setOnMouseClicked(this);
        main_info.setEditable(false); rating.setEditable(false);
        rating.setText(String.valueOf(service_dr.getSummaryRating(service_d.getUsername())));
        main_info.setText((service_d.getDistributorInfo(service_d.getUsername())).toString());}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == buttonShow) {
            LocalDate date_from = from.getValue();
            LocalDate date_to = to.getValue();
            ObservableList<String> events = service_evd.getEventsByDistributor(service_d.getUsername(), date_from, date_to);
            eventsList.setItems(events);}
        else if (event.getSource() == buttonMenu) { service_d.getDistributorMenuView(event);}}
}




