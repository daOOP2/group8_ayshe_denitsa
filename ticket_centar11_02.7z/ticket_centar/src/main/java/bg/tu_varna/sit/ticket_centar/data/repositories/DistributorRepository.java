package bg.tu_varna.sit.ticket_centar.data.repositories;
import bg.tu_varna.sit.ticket_centar.data.access.Connection;
import bg.tu_varna.sit.ticket_centar.data.entities.Distributor;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.LinkedList;
import java.util.List;

public class DistributorRepository implements DAORepository<Distributor> {

    private static final Logger log = Logger.getLogger(DistributorRepository.class);

    public static DistributorRepository getInstance() { return DistributorRepository.DistributorRepositoryHolder.INSTANCE;}

    private static class DistributorRepositoryHolder {
        public static final DistributorRepository INSTANCE = new DistributorRepository();
    }

    @Override
    public void save(Distributor distributor) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(distributor);
            log.info("Distributor saved successfully");
        } catch (Exception ex) {
            log.error("Distributor save error" + ex.getMessage());
        } finally {
            transaction.commit();   }
    }

    @Override
    public void update(Distributor distributor) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            Distributor d = session.get(Distributor.class, distributor.getDistributorId());
            d.setDistributorHonorarium(distributor.getDistributorHonorarium());
            d.setDistributorAddress(distributor.getDistributorAddress());
            d.setDistributorEmail(distributor.getDistributorEmail());
            d.setDistributorPhoneNumber(distributor.getDistributorPhoneNumber());
            session.update(d);
            log.info("Distributor updated successfully");
        } catch (Exception ex) {
            log.error("Distributor update error" + ex.getMessage());
        } finally {
            transaction.commit();   }
    }

    @Override
    public void delete(Distributor distributor) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.delete(distributor);
            log.info("Distributor deleted successfully");
        } catch (Exception ex) {
            log.error("Distributor delete error" + ex.getMessage());
        } finally {
            transaction.commit();   }
    }

    @Override
    public List<Distributor> getAll() {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        List<Distributor> Distributor = new LinkedList<>();
        try {
            String jpql = "SELECT d FROM Distributor  d";
            Distributor.addAll(session.createQuery(jpql, Distributor.class).getResultList());
            log.info("Get all Distributors");
        } catch (Exception ex) {
            log.error("Get Distributor error: " + ex.getMessage());
        } finally {
            transaction.commit();
           //Connection.openSessionClose();
        }

        return Distributor;
    }

}


