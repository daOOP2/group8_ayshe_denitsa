package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Save;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.business.servicec.PlacePriceService;
import bg.tu_varna.sit.ticket_centar.presentation.models.PlacePriceModel;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class PlacePriceController implements EventHandler<MouseEvent> {

    private final PlacePriceService service_place = PlacePriceService.getInstance();
    private final OrganizerService service_o = OrganizerService.getInstance();

    @FXML private Button save, menu, show;

    @FXML private TextField placeType, placePrice, result;

    @FXML private ListView<PlacePriceModel> place_price;

    @FXML private void initialize() {
        save.setOnMouseClicked(this); menu.setOnMouseClicked(this);
        show.setOnMouseClicked(this); result.setEditable(false);}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == save) {
            if(Double.parseDouble(placePrice.getText())<0){result.setText("Incorrect Data!");}
            else{
            PlacePriceModel ppm = new PlacePriceModel(placeType.getText().toLowerCase(), Double.parseDouble(placePrice.getText()));
            boolean r = service_place.SavePlacePrice(ppm);
            if(r){result.setText("Saved Successfully!");}
            else{result.setText("Save Error!");}
            }}
        else if (event.getSource() == show) {
            ObservableList<PlacePriceModel> place_prices = service_place.getAllPrices();
            place_price.setItems(place_prices);}
        else if (event.getSource() == menu) { service_o.getOrganizerMenuView(event); }}
}
