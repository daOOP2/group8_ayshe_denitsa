package bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Update;
import bg.tu_varna.sit.ticket_centar.business.servicec.AdministratorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.OrganizerModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class UpdateOrganizerCotroller implements EventHandler<MouseEvent> {

    private final OrganizerService service_o = OrganizerService.getInstance();
    private final AdministratorService service_adm = AdministratorService.getInstance();

    @FXML
    private Button Update, Menu, loadInfo;

    @FXML private TextField tfFirstName, tfLastName, tfUsername, tfPassword, tfPhoneNumber, tfAddress, tfID, tfEmail, tfBg, tfResult, tfHonorarium;

    @FXML private void initialize() {  Menu.setOnMouseClicked(this);
        Update.setOnMouseClicked(this); loadInfo.setOnMouseClicked(this);
        tfBg.setText("+359"); tfBg.setEditable(false);tfResult.setEditable(false);
        tfFirstName.setEditable(false); tfLastName.setEditable(false);
        tfUsername.setEditable(false);  tfPassword.setEditable(false);
    }

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == Update)
        {
            OrganizerModel model = new OrganizerModel();
            model.setOrganizer_email(tfEmail.getText());
            model.setOrganizer_phone_number(tfBg.getText()+tfPhoneNumber.getText());
            model.setOrganizer_honorarium(Double.parseDouble(tfHonorarium.getText()));
            model.setOrganizer_address(tfAddress.getText());
            if(service_o.UpdateOrganizer(model,Long.parseLong(tfID.getText()))){tfResult.setText("UpdatedSuccessfully!");}
            else {tfResult.setText("Data Is Not Correct!");}
        }
        else if (event.getSource() == loadInfo) {
           OrganizerModel model = service_o.getOrganizerModelByID(Long.parseLong(tfID.getText()));
            tfFirstName.setText(model.getOrganizer_first_name()); tfLastName.setText(model.getOrganizer_last_name());
            tfUsername.setText(model.getOrganizer_username()); tfPassword.setText(model.getOrganizer_password());
            tfEmail.setText(model.getOrganizer_email()); tfPhoneNumber.setText(model.getOrganizer_phone_number().substring(4));
            tfAddress.setText(model.getOrganizer_address()); tfHonorarium.setText(String.valueOf(model.getOrganizer_honorarium()));}
        else if (event.getSource() == Menu) { service_adm.getAdminView(event); }
    }
}