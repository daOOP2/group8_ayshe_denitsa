package bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Save;
import bg.tu_varna.sit.ticket_centar.business.servicec.AdministratorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.presentation.models.DistributorModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class AddDistributorController implements EventHandler<MouseEvent> {

    private final DistributorService service_d = DistributorService.getInstance();
    private final AdministratorService service_adm = AdministratorService.getInstance();

    @FXML private Button buttonCreate, buttonMenu;
    @FXML private TextField tfFirstName, tfLastName, tfUsername, tfPassword, tfPhoneNumber, tfAddress, tfHonorarium, tfDistributorID, tfEmail, tfBg, tfResult;

    @FXML private void initialize() {
    buttonCreate.setOnMouseClicked(this); buttonMenu.setOnMouseClicked(this);
    tfBg.setText("+359"); tfBg.setEditable(false);
    tfResult.setEditable(false); }

    @Override public void handle(MouseEvent event) {
    if (event.getSource() == buttonCreate) {
        String phone = tfBg.getText()+tfPhoneNumber.getText();
        DistributorModel newDistributor = new DistributorModel(tfFirstName.getText().toLowerCase(), tfLastName.getText().toLowerCase(), tfUsername.getText(), tfPassword.getText(), tfEmail.getText(), phone, tfAddress.getText(), Double.parseDouble(tfHonorarium.getText()), Long.parseLong(tfDistributorID.getText()), service_adm.getUsername());
           if(!service_d.checkInputData(newDistributor))
              { tfResult.setText("Incorrect Data!"); }
           else
              { boolean result = service_d.SaveDistributor(newDistributor);
                if(result){tfResult.setText("Added Successfully!");}
                else{tfResult.setText("Save Error!");}}}

    else if (event.getSource() == buttonMenu) { service_adm.getAdminView(event); } }
}

