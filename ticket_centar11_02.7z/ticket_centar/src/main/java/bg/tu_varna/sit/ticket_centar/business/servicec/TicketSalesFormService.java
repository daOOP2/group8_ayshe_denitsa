package bg.tu_varna.sit.ticket_centar.business.servicec;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import bg.tu_varna.sit.ticket_centar.data.entities.*;
import bg.tu_varna.sit.ticket_centar.data.repositories.DistributorRepository;
import bg.tu_varna.sit.ticket_centar.data.repositories.EventDistributorRepository;
import bg.tu_varna.sit.ticket_centar.data.repositories.EventRepository;
import bg.tu_varna.sit.ticket_centar.data.repositories.TicketSalesFormRepository;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventDistributorModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventPlacesModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.TicketSalesFormModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class TicketSalesFormService{

    private final TicketSalesFormRepository repository = TicketSalesFormRepository.getInstance();
    private final EventService service_event = EventService.getInstance();
    private final DistributorService service_distributor = DistributorService.getInstance();
    private final PlacePriceService service_place_price = PlacePriceService.getInstance();
    private final EventPlacesService service_event_places = EventPlacesService.getInstance();
    private final EventDistributorService service_event_distributor = EventDistributorService.getInstance();

    public static TicketSalesFormService getInstance() { return TicketSalesFormService.TicketSalesFormServiceHolder.INSTANCE;}
    private static class TicketSalesFormServiceHolder { public static final TicketSalesFormService INSTANCE = new TicketSalesFormService();}

    public ObservableList<TicketSalesFormModel> getAllForms() {
        List<TicketSalesForm> forms = repository.getAll();
        return FXCollections.observableList(
                forms
                        .stream()
                        .map(t -> new TicketSalesFormModel(
                               t.getClientFirstName(),
                                t.getClientLastName(),
                                t.getPhoneNumber(),
                                t.getEvent().getEventName(),
                                t.getPlacePrice().getPlaceType(),
                                t.getDistributor().getDistributorUsername(),
                                t.getSaleDate()
                        )).collect(Collectors.toList()));}

    public int getSoldTicketsForEvent(String event_name){ int sold = 0;
        List<TicketSalesFormModel>forms=getAllForms();
        for(TicketSalesFormModel t : forms){
        if(t.getEvent_name().equals(event_name)) {sold=sold+1;}}
        return sold;}

    public ObservableList<String>soldTicketsForLastWeek(String organizer_username)
    {
        ObservableList<String> list =FXCollections.observableArrayList();
        List<TicketSalesFormModel> forms = getAllForms();
        List<EventModel> events = service_event.getAllEvents();

        for(EventModel e : events)
        {
            if(e.getOrganizer_username().equals(organizer_username))
            {
                for(TicketSalesFormModel t : forms)
                {
                    if(t.getEvent_name().equals(e.getEvent_name()))
                    {
                        if((LocalDate.parse(t.getSale_date()).getMonth()==LocalDate.now().getMonth())&&((LocalDate.parse(t.getSale_date()).getYear())==LocalDate.now().getYear()))
                        {
                            if(((LocalDate.parse(t.getSale_date()).getDayOfMonth())<(LocalDate.now().getDayOfMonth()+1))&&((LocalDate.parse(t.getSale_date()).getDayOfMonth())>(LocalDate.now().getDayOfMonth()-7)))
                            {
                                String s = "Date : "+t.getSale_date()+" Event: "+e.getEvent_name()+" Client Name: "+ t.getClient_first_name()+ " "+t.getClient_last_name()+" Phone Number: "+t.getPhone_number();
                                list.add(s);
                            }
                        }
                    }
                }
            }
        }

        return list;
    }

    public String getClientFullName (String phone_number)
    {
        String name="";
        List <TicketSalesFormModel> forms = getAllForms();
        for(TicketSalesFormModel t : forms)
        {
            if(t.getPhone_number().equals(phone_number))
            {
                name = t.getClient_first_name() + " " + t.getClient_last_name();
            }
        }
        return name;
    }

    public boolean CheckPhoneNumberIfExistsOrCorrect(String newPhoneNumber)
    {
        if(newPhoneNumber.length()!=13)
        {
            return false;
        }

        List<TicketSalesFormModel> forms = getAllForms();
        for(TicketSalesFormModel t : forms)
        {
            if((t.getPhone_number().equals(newPhoneNumber)))
            {
                return false;
            }
        }
        return true;
    }

    public boolean CheckForDistributor(TicketSalesFormModel model)
    {
        List<EventDistributorModel>distributors= service_event_distributor.getAllEventDistributors();
        for(EventDistributorModel e:distributors)
        {
            if ((e.getEvent_name().equals(model.getEvent_name()))&&(e.getDistributor_username().equals(model.getDistributor_username())))
            {
                return true;
            }
        }
        return false;
    }

    public boolean CheckMaxTicketsPerPerson(TicketSalesFormModel model)
    {
        int br = 0;
        int max_per_person = service_event.getEventByName(model.getEvent_name()).getMaxNumberOfTicketsPerPerson();
        List<TicketSalesFormModel>forms= getAllForms();
        for(TicketSalesFormModel t : forms)
        {
            if((t.getEvent_name().equals(model.getEvent_name())))
            {
                if((t.getClient_first_name().equals(model.getClient_first_name()))&&(t.getClient_last_name().equals(model.getClient_last_name()))&&(t.getPhone_number().equals(model.getPhone_number())))
                {
                    br++;
                }
            }
        }
        return max_per_person > br;
    }

        public boolean CheckForSoldOut(TicketSalesFormModel model)
        {
            int sold = 0; int tickets_number_type = 0;
            List<TicketSalesFormModel>forms= getAllForms();
            List<EventPlacesModel>places=service_event_places.getAllEventPlaces();
            for(EventPlacesModel e : places)
            {
                if((e.getEvent_name().equals(model.getEvent_name()))&&(e.getPlace_type().equals(model.getPlace_type())))
                {
                    tickets_number_type=e.getNumber_of_tickets();
                }
            }
        for(TicketSalesFormModel t:forms)
        {
           if((t.getEvent_name().equals(model.getEvent_name()))&&(t.getPlace_type().equals(model.getPlace_type())))
           {
               sold++;
           }
        }
        if(sold>=tickets_number_type)
        {
            return false;
        }
        return true;}

    public boolean CheckClientInformation(TicketSalesFormModel model)
    {
        if(model.getPhone_number().length()!=13)
        {
            return false;
        }
        List<TicketSalesFormModel>forms= getAllForms();
        for(TicketSalesFormModel t : forms)
        {
            if(t.getPhone_number().equals(model.getPhone_number()))
            {
                if(!((t.getClient_first_name().equals(model.getClient_first_name()))&&(t.getClient_last_name().equals(model.getClient_last_name()))))
                {
                    return false;
                }
            }
        }
        return true;
    }

    public double SaveTicketSalesForm(TicketSalesFormModel model)
    {
        if(!CheckForDistributor(model)){return 0;}
        if(!CheckMaxTicketsPerPerson(model)){return 0;}
        if(!CheckForSoldOut(model)){return 0;}
        if(!CheckClientInformation(model)){return 0;}
        double price=0;
        TicketSalesForm t = new TicketSalesForm();
        t.setClientFirstName(model.getClient_first_name());
        t.setClientLastName(model.getClient_last_name());
        t.setPhoneNumber(model.getPhone_number());
        t.setEvent(service_event.getEventByName(model.getEvent_name()));
        t.setPlacePrice(service_place_price.getPlaceByType(model.getPlace_type()));
        t.setDistributor(service_distributor.getDistributorByUsername(model.getDistributor_username()));
        t.setSaleDate(model.getSale_date());
        price = t.getPlacePrice().getPlacePrice();
        repository.save(t);
        return price;
    }

    public boolean UpdateTicketSalesForm(String old_phone_number, String new_phone_number)
    {
        if(!CheckPhoneNumberIfExistsOrCorrect(new_phone_number)) {return false;}

        List<TicketSalesForm>all = TicketSalesFormRepository.getInstance().getAll();
        for(TicketSalesForm t : all) {
            if(t.getDistributor().getDistributorUsername().equals(service_distributor.getUsername())) {
                if (t.getPhoneNumber().equals(old_phone_number)) {
                    t.setPhoneNumber(new_phone_number);
                    repository.update(t);
                }}}
        return true;
    }

    public void DeleteTicketSalesForm(String phone_number){
        List<TicketSalesForm>all = TicketSalesFormRepository.getInstance().getAll();
        for(TicketSalesForm t : all)
        {
            if(t.getDistributor().getDistributorUsername().equals(service_distributor.getUsername())) {
                if (t.getPhoneNumber().equals(phone_number)) {
                    repository.delete(t);
                }
            }
        }
    }

    public void getTicketSalesFormView(MouseEvent event){
        try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.TICKET_SALES_FORM)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
        catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getUpdateDeleteTicketSalesFormView(MouseEvent event) {
        try {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.UPDATE_DELETE_TICKET_SALES_FORM)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
    catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}
}
