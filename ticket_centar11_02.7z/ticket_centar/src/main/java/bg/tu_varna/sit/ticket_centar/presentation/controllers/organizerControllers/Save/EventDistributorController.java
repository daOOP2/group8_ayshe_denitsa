package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Save;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventDistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventDistributorModel;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.time.LocalDate;

public class EventDistributorController implements EventHandler<MouseEvent> {

    private final EventDistributorService service_event_d = EventDistributorService.getInstance();
    private final OrganizerService service_o = OrganizerService.getInstance();

    @FXML private Button save, menu, show;

    @FXML private TextField distributorUsername, eventName, result;

    @FXML private ListView<EventDistributorModel> eventDistributors;

    @FXML private void initialize() {
        save.setOnMouseClicked(this); menu.setOnMouseClicked(this);
        show.setOnMouseClicked(this); result.setEditable(false);}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == save) {
            EventDistributorModel edm = new EventDistributorModel(distributorUsername.getText().toLowerCase(),eventName.getText().toLowerCase(), String.valueOf(LocalDate.now()));
            boolean r = service_event_d.SaveEventDistributor(edm);
            if(r){result.setText("Saved Successfully!");}
            else{result.setText("Incorrect Data!");}
        }
       else if (event.getSource() == show) {
            ObservableList<EventDistributorModel> event_distributors = service_event_d.getAllEventDistributors();
            eventDistributors.setItems(event_distributors);}
        else if (event.getSource() == menu) { service_o.getOrganizerMenuView(event);}}
}
