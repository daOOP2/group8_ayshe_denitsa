package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.UpdateDelete;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorRatingService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.DistributorRatingModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class UpdateDeleteRateDistributorController implements EventHandler<MouseEvent> {

    private final OrganizerService service_o = OrganizerService.getInstance();
    private final DistributorRatingService service_dr = DistributorRatingService.getInstance();

    @FXML
    private Button delete, menu, update, load;

    @FXML private TextField result, usernameDistributor, percentage;

    @FXML private void initialize() {
        menu.setOnMouseClicked(this); delete.setOnMouseClicked(this);
        update.setOnMouseClicked(this); load.setOnMouseClicked(this);
        result.setEditable(false);
    }

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == delete)
        {
            DistributorRatingModel dr = new DistributorRatingModel();
            dr.setDistributor_username(usernameDistributor.getText());
            service_dr.DeleteDistributorRating(dr);
        }
        else if(event.getSource()==update)
        {
            DistributorRatingModel dr = new DistributorRatingModel();
            dr.setDistributor_username(usernameDistributor.getText());
            dr.setRating_percentage(Double.parseDouble(percentage.getText()));
            if(!service_dr.UpdateDistributorRating(dr))
            {
                result.setText("Incorrect Data!");
            }

        }
        else if(event.getSource()==load)
        {
            percentage.setText(String.valueOf(service_dr.getRatingPercentage(usernameDistributor.getText())));
        }
        else if (event.getSource() == menu)
        {
            service_o.getOrganizerMenuView(event);
        }
    }
}

