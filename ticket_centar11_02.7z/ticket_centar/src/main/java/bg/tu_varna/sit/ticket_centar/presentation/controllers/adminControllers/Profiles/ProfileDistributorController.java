package bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Profiles;
import bg.tu_varna.sit.ticket_centar.business.servicec.AdministratorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.presentation.models.DistributorModel;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;


public class ProfileDistributorController implements EventHandler<MouseEvent> {

    private final DistributorService service = DistributorService.getInstance();
    private final AdministratorService service_adm = AdministratorService.getInstance();

    @FXML private Button buttonMenu;

    @FXML private ListView<DistributorModel> listViewDistributor;

    @FXML private void initialize() {
        buttonMenu.setOnMouseClicked(this);
        ObservableList<DistributorModel> distributors = service.getAllDistributors();
        listViewDistributor.setItems(distributors);
    }

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == buttonMenu) { service_adm.getAdminView(event); }
    }
}

