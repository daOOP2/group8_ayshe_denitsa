package bg.tu_varna.sit.ticket_centar.data.repositories;
import bg.tu_varna.sit.ticket_centar.data.access.Connection;
import bg.tu_varna.sit.ticket_centar.data.entities.DistributorRating;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.LinkedList;
import java.util.List;


public class DistributorRatingRepository implements DAORepository<DistributorRating> {

    private static final Logger log = Logger.getLogger(DistributorRatingRepository.class);

    public static DistributorRatingRepository getInstance() { return DistributorRatingRepository.DistributorRatingRepositoryHolder.INSTANCE;}

    private static class DistributorRatingRepositoryHolder {
        public static final DistributorRatingRepository INSTANCE = new DistributorRatingRepository();
    }

    @Override
    public void save(DistributorRating distributor_rating) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(distributor_rating);
            log.info("Distributor Rating saved successfully");
        } catch (Exception ex) {
            log.error("Distributor Rating save error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void update(DistributorRating distributor_rating) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            DistributorRating r = session.get(DistributorRating.class, distributor_rating.getRatingId());
            r.setRatingPercentage(distributor_rating.getRatingPercentage());
            session.update(r);
            log.info("Distributor Rating updated successfully");
        } catch (Exception ex) {
            log.error("Distributor Rating update error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void delete(DistributorRating distributor_rating) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            DistributorRating r = session.get(DistributorRating.class, distributor_rating.getRatingId());
            session.delete(r);
            log.info("Distributor Rating deleted successfully");
        } catch (Exception ex) {
            log.error("Distributor Rating delete error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public List<DistributorRating> getAll() {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        List<DistributorRating> distributor_rating = new LinkedList<>();
        try {
            String jpql = "SELECT dr FROM DistributorRating  dr";

            distributor_rating.addAll(session.createQuery(jpql, DistributorRating.class).getResultList());
            log.info("Get all Distributors Ratings");
        } catch (Exception ex) {
            log.error("Get Distributor Rating error: " + ex.getMessage());
        } finally {
            transaction.commit();
            //Connection.openSessionClose();
        }

        return distributor_rating;
    }
}

