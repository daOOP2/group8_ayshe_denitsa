package bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.Save;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.TicketSalesFormService;
import bg.tu_varna.sit.ticket_centar.presentation.models.TicketSalesFormModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.time.LocalDate;

public class TicketSalesFormController implements EventHandler<MouseEvent> {

    private final TicketSalesFormService service_tsf = TicketSalesFormService.getInstance();
    private final DistributorService service_d = DistributorService.getInstance();

    @FXML private Button returnMenu , OK;

    @FXML private TextField firstName, lastName, eventName, placeType, bg, phoneNumber, result, price;

    @FXML private void initialize() {
        OK.setOnMouseClicked(this); returnMenu.setOnMouseClicked(this);
        bg.setText("+359"); bg.setEditable(false);
        result.setEditable(false);
        price.setEditable(false); price.setText("0.0");}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == OK) {
            String phone = bg.getText() + phoneNumber.getText();
            TicketSalesFormModel tsf = new TicketSalesFormModel(firstName.getText().toLowerCase(), lastName.getText().toLowerCase(), phone, eventName.getText().toLowerCase(), placeType.getText().toLowerCase(), service_d.getUsername(), String.valueOf(LocalDate.now()));
            if(!service_tsf.CheckClientInformation(tsf)){result.setText("Incorrect Client Information!");}
            else if(!service_tsf.CheckForDistributor(tsf)){result.setText("Wrong Distributor!");}
            else if(!service_tsf.CheckMaxTicketsPerPerson(tsf)){result.setText("Max Tickets Already Bought!");}
            else if(!service_tsf.CheckForSoldOut(tsf)){result.setText("Sold Out For Type!");}
            else{ double r =service_tsf.SaveTicketSalesForm(tsf);
            if(r>0){result.setText("Saved Successfully!"); price.setText(String.valueOf(r));}
            else {result.setText("Save Error!");}}
        }
        else if (event.getSource() == returnMenu) { service_d.getDistributorMenuView(event);}}
    }

