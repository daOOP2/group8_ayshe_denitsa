package bg.tu_varna.sit.ticket_centar.business.servicec;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import bg.tu_varna.sit.ticket_centar.data.entities.*;
import bg.tu_varna.sit.ticket_centar.data.repositories.*;
import bg.tu_varna.sit.ticket_centar.presentation.models.DistributorModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventDistributorModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.TicketSalesFormModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class EventService {

    private final EventRepository repository = EventRepository.getInstance();
    private final OrganizerService service_organizer = OrganizerService.getInstance();

    public static EventService getInstance() {return EventService.EventServiceHolder.INSTANCE;}
    private static class EventServiceHolder { public static final EventService INSTANCE = new EventService();}

    public ObservableList<EventModel> getAllEvents() {
        List<Event> events = repository.getAll();
        return FXCollections.observableList(
                events
                        .stream()
                        .map(e -> new EventModel(
                                e.getEventName(),
                                e.getEventType(),
                                e.getEventStatus(),
                                e.getEventNumberOfPlaces(),
                                e.getEventDate(),
                                e.getMaxNumberOfTicketsPerPerson(),
                                e.getEventId(),
                                e.getOrganizer().getOrganizerUsername(),
                                e.getAddress(),
                                e.getDateOfCreation(),
                                e.getEventDetails()

                        )).collect(Collectors.toList()));}

    public ObservableList<String> getEventsByOrganizer(String username_event, LocalDate date_from, LocalDate date_to){  // my events for period
        ObservableList<String> list =FXCollections.observableArrayList();
        String event="";
        List<EventModel>events=getAllEvents();
        for(EventModel e:events)
        {
         if(e.getOrganizer_username().equals(username_event))
         {
             if((LocalDate.parse(e.getEvent_date()).isBefore(date_to))&&(LocalDate.parse(e.getEvent_date()).isAfter(date_from)))
             {
                 event = "Event : "+e.getEvent_name() + " " + e.getEvent_date() + " Number Of Tickets : "+ e.getEvent_number_of_places()+" Sold Tickets: "+TicketSalesFormService.getInstance().getSoldTicketsForEvent(e.getEvent_name());
                 list.add(event);
             }
         }
        }
        return list;}

    public String setStatus(String date) {
        String status="";
        if(LocalDate.parse(date).isAfter(LocalDate.now())) { status="scheduled"; } else { status="closed"; }
        return status;}

    public Event getEventByName(String name){ Event ev = new Event();
        List<Event>events= EventRepository.getInstance().getAll();
        for(Event e : events){if(e.getEventName().equals(name)){ev=e;}}
        return ev;}

    public ObservableList<String> eventsThisMonth(){
        LocalDate date;
        ObservableList<String> list =FXCollections.observableArrayList();
        List<EventModel>events=getAllEvents();
       for(EventModel e : events){
           if(e.getEvent_number_of_places()>TicketSalesFormService.getInstance().getSoldTicketsForEvent(e.getEvent_name()))
           {
           date = LocalDate.parse(e.getEvent_date());
           if((date.isAfter(LocalDate.now()))&&(date.getMonthValue()<(LocalDate.now().getMonthValue()+1)))
           {
               String event = "Event Name : "+ e.getEvent_name() + " Date : "+ e.getEvent_date() + " Number Of Places : " + e.getEvent_number_of_places() + " Sold: " + TicketSalesFormService.getInstance().getSoldTicketsForEvent(e.getEvent_name());
               list.add(event);
           }
           }
       }
        return list;}

    public EventModel getInfo(Long number) {  //update
        List<EventModel> all = getAllEvents();
        EventModel model = new EventModel();
        for(EventModel m : all) { if(m.getEvent_id().equals(number)) { model = m; }}
        return model;}

    public boolean SaveEvent(EventModel model){ Event evt = new Event();
        List<Event>events= EventRepository.getInstance().getAll();
        evt.setEventName(model.getEvent_name());
        evt.setEventType(model.getEvent_type());
        evt.setEventStatus(model.getEvent_status());
        evt.setAddress(model.getAddress());
        evt.setEventNumberOfPlaces(model.getEvent_number_of_places());
        evt.setEventDate(model.getEvent_date());
        evt.setMaxNumberOfTicketsPerPerson(model.getMax_number_of_tickets_per_person());
        evt.setOrganizer(service_organizer.getOrganizerByUsername(model.getOrganizer_username()));
        evt.setEventId(model.getEvent_id());
        evt.setDateOfCreation(model.getDate_of_creation());
        evt.setEventDetails(model.getEvent_details());
        for(Event event:events){if((event.getEventName().equals(evt.getEventName()))) {return false;}}
        repository.save(evt);
        return true;}

    public boolean CheckNameIfAlreadyExists(EventModel model, Long number)
    {
        List <Event> all = EventRepository.getInstance().getAll();
        for(Event e : all)
        {
            if((e.getEventName().equals(model.getEvent_name()))&&(!e.getEventId().equals(number)))
            {
                return false;
            }
        }
        return true;
    }

    public boolean CheckIfNumberOfPlacesIsEnough(EventModel model)
    {
        int distributed=0;
        List <EventPlaces> all = EventPlacesRepository.getInstance().getAll();
        for(EventPlaces e : all)
        {
            if(e.getEvent().getEventName().equals(model.getEvent_name()))
            {
                distributed = distributed+e.getNumberOfTickets();
            }
        }
        if(distributed>model.getEvent_number_of_places()){return false;}
        return true;
    }

    public boolean UpdateEvent(EventModel model, Long ID)
    {

       if(!CheckNameIfAlreadyExists(model,ID)){return false;}
       if((model.getMax_number_of_tickets_per_person()<1)||(model.getMax_number_of_tickets_per_person()>model.getEvent_number_of_places())){return false;}
       if(!CheckIfNumberOfPlacesIsEnough(model)){return false;}
        List <Event> all = EventRepository.getInstance().getAll();
        for(Event e : all)
        {
            if(e.getEventId().equals(ID))
            {
                e.setEventDetails(model.getEvent_details());
                e.setAddress(model.getAddress());
                e.setMaxNumberOfTicketsPerPerson(model.getMax_number_of_tickets_per_person());
                e.setEventNumberOfPlaces(model.getEvent_number_of_places());
                e.setEventName(model.getEvent_name());
                e.setEventStatus(model.getEvent_status());
                e.setEventType(model.getEvent_type());
                repository.update(e);
            }
        }
        return true;
    }

    public void getNewEventView(MouseEvent event){ try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.EVENT_VIEW)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getUpdateEventView(MouseEvent event){ try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.UPDATE_EVENT_VIEW)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}
}