package bg.tu_varna.sit.ticket_centar.data.entities;
import javax.persistence.*;


@Table(name = "event_distributors")
@Entity
public class EventDistributor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "event_distributor_id", nullable = false)
    private Long event_distributor_id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "distributor_id", nullable = false)
    private Distributor distributor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "event_id", nullable = false)
    private Event event;

    @Column(name="date", nullable = false)
    private String date;

    public EventDistributor(){}

    public Long getEventDistributorId() {
        return event_distributor_id;
    }
    public void setEventDistributorId(Long event_distributor_id) {this.event_distributor_id = event_distributor_id;}

    public Distributor getDistributor() {return distributor;}
    public void setDistributor(Distributor distributor) {this.distributor = distributor;}

    public Event getEvent() {return event;}
    public void setEvent(Event event) {this.event = event;}

    public String getDate() {return date;}
    public void setDate(String date){this.date=date;}


    @Override
    public String toString() {
        return "event_distributor{" +
                "event_distributor_id=" + event_distributor_id +
                ", distributor=" + distributor +
                ", event=" + event +
                '}';
    }
}
