package bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Update;
import bg.tu_varna.sit.ticket_centar.business.servicec.AdministratorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.presentation.models.DistributorModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class UpdateDistributorController implements EventHandler<MouseEvent> {

    private final DistributorService service_d = DistributorService.getInstance();
    private final AdministratorService service_adm = AdministratorService.getInstance();

    @FXML private Button Update, Menu, loadInfo;

    @FXML private TextField tfFirstName, tfLastName, tfUsername, tfPassword, tfPhoneNumber, tfAddress, tfID, tfEmail, tfBg, tfResult, tfHonorarium;

    @FXML private void initialize() {

        Update.setOnMouseClicked(this);
        Menu.setOnMouseClicked(this);
        loadInfo.setOnMouseClicked(this);

        tfBg.setText("+359"); tfBg.setEditable(false);tfResult.setEditable(false);

        tfFirstName.setEditable(false); tfLastName.setEditable(false);
        tfPassword.setEditable(false); tfUsername.setEditable(false);}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == Update)
        {
            DistributorModel newDistributor = new DistributorModel();
            newDistributor.setDistributor_honorarium(Double.parseDouble(tfHonorarium.getText()));
            newDistributor.setDistributor_address(tfAddress.getText().toLowerCase());
            newDistributor.setDistributor_phone_number(tfBg.getText()+tfPhoneNumber.getText());
            newDistributor.setDistributor_email(tfEmail.getText());
            newDistributor.setDistributor_id(Long.parseLong(tfID.getText()));

           if(!service_d.checkInputData(newDistributor)){ tfResult.setText("Incorrect Data!");}
           else if(!service_d.CheckPhoneNumberIfExistsOrCorrect(newDistributor)){tfResult.setText("Phone Number Is Not Correct!");}
           else if(!service_d.CheckEmailIfExists(newDistributor)){tfResult.setText("Email Is Not Correct!");}
           else {

               service_d.UpdateDistributor(newDistributor);
               tfResult.setText("");
           }


        }
        else if (event.getSource() == loadInfo) {
           DistributorModel model = service_d.getDistributorModelByID(Long.parseLong(tfID.getText()));
           tfFirstName.setText(model.getDistributor_first_name());
           tfLastName.setText(model.getDistributor_last_name());
           tfUsername.setText(model.getDistributor_username());
           tfPassword.setText(model.getDistributor_password());
           tfEmail.setText(model.getDistributor_email());
           tfPhoneNumber.setText(model.getDistributor_phone_number().substring(4));
           tfAddress.setText(model.getDistributor_address());
           tfHonorarium.setText(String.valueOf(model.getDistributor_honorarium()));}
        else if (event.getSource() == Menu) { service_adm.getAdminView(event); }
    }
}