package bg.tu_varna.sit.ticket_centar.data.entities;
import javax.persistence.*;
import java.util.Set;

@Table(name = "distributors")
@Entity
public class Distributor {
    private static final long serialVersionUID = 2L;

    @Column(name = "distributor_first_name", nullable = false)
    private String distributor_first_name;

    @Column(name = "distributor_last_name", nullable = false)
    private String distributor_last_name;

    @Column(name = "distributor_username", nullable = false, unique = true)
    private String distributor_username;

    @Column(name = "distributor_password", nullable = false, unique = true)
    private String distributor_password;

    @Column(name = "distributor_email", nullable = false, unique = true)
    private String distributor_email;

    @Column(name = "distributor_phone_number", nullable = false, unique = true)
    private String distributor_phone_number;

    @Column(name = "distributor_address", nullable = false)
    private String distributor_address;

    @Column(name="distributor_honorarium", nullable=false)
    private Double distributor_honorarium;

    @Id
    @Column(name = "distributor_id", nullable = false, unique = true)
    private Long distributor_id;

    @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
    private Set<EventDistributor> eventDistributorSet;

    @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
    private Set<TicketSalesForm> ticketSalesFormSet;

    @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
    private Set<DistributorRating> distributorRatingSet;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "admin_id", nullable = false)
    private Administrator admin;

    public Distributor(){}

    public Long getDistributorId() {
        return distributor_id;
    }
    public void setDistributorId(Long admin_id) {
        this.distributor_id = admin_id;
    }

    public String getDistributorFirstName() {
        return distributor_first_name;
    }
    public void setDistributorFirstName(String distributor_first_name) {this.distributor_first_name = distributor_first_name;}

    public String getDistributorLastName() {return distributor_last_name;}
    public void setDistributorLastName(String distributor_last_name) {this.distributor_last_name = distributor_last_name;}

    public String getDistributorUsername() {
        return distributor_username;
    }
    public void setDistributorUsername(String distributor_username) {this.distributor_username = distributor_username;}

    public String getDistributorPassword() {
        return distributor_password;
    }
    public void setDistributorPassword(String distributor_password) {this.distributor_password = distributor_password;}

    public String getDistributorEmail() {
        return distributor_email;
    }
    public void setDistributorEmail(String distributor_email) {
        this.distributor_email = distributor_email;
    }

    public String getDistributorPhoneNumber() {
        return distributor_phone_number;
    }
    public void setDistributorPhoneNumber(String distributor_phone_number) {this.distributor_phone_number = distributor_phone_number;}

    public String getDistributorAddress() {
        return distributor_address;
    }
    public void setDistributorAddress(String distributor_address) {
        this.distributor_address = distributor_address;
    }

    public Double getDistributorHonorarium(){return distributor_honorarium;}
    public void setDistributorHonorarium(Double distributor_honorarium){this.distributor_honorarium=distributor_honorarium;}

    public Administrator getAdmin() {return admin;}
    public void setAdmin(Administrator admin) {this.admin = admin;}

    public Set<EventDistributor> getEventDistributorSet() {return eventDistributorSet;}
    public void setEventDistributorSet(Set<EventDistributor> eventDistributorSet) {this.eventDistributorSet = eventDistributorSet;}

    public Set<TicketSalesForm> getTicketSalesFormSet() {return ticketSalesFormSet;}
    public void setTicketSalesFormSet(Set<TicketSalesForm> ticketSalesFormSet) {this.ticketSalesFormSet = ticketSalesFormSet;}

    public Set<DistributorRating> getDistributorRatingSet() {return distributorRatingSet;}
    public void setDistributorRatingSet(Set<DistributorRating> distributorRatingSet) {this.distributorRatingSet = distributorRatingSet;}

    @Override
    public String toString() {
        return "distributor{" +
                "distributor_first_name='" + distributor_first_name +'\''+
                ", distributor_last_name='" + distributor_last_name + '\'' +
                ", distributor_username='" + distributor_username + '\'' +
                ", distributor_password='" + distributor_password + '\'' +
                ", distributor_email='" + distributor_email + '\'' +
                ", distributor_phone_number='" + distributor_phone_number + '\'' +
                ", distributor_address='" + distributor_address + '\'' +
                ", distributor_honorarium=" + distributor_honorarium +
                ", distributor_id=" + distributor_id +
                ", admin=" + admin +
                ", eventDistributorSet=" + eventDistributorSet +
                ", ticketSalesFormSet=" + ticketSalesFormSet +
                ", distributorRatingSet=" + distributorRatingSet+
                '}';
    }
}
