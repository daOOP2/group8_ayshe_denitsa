package bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.Menu;
import bg.tu_varna.sit.ticket_centar.business.servicec.*;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;

import java.time.LocalDate;

public class DistributorMenuController implements EventHandler<MouseEvent> {

    private final DistributorService service_d = DistributorService.getInstance();
    private final AdministratorService service_adm = AdministratorService.getInstance();
    private final TicketSalesFormService service_tsf = TicketSalesFormService.getInstance();

    @FXML private Button notifications, eventsAndInformation, updateDeleteForms, sellTickets, logOut;

    @FXML private void initialize() {
        notifications.setOnMouseClicked(this); eventsAndInformation.setOnMouseClicked(this);
        updateDeleteForms.setOnMouseClicked(this); sellTickets.setOnMouseClicked(this);
        logOut.setOnMouseClicked(this);}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == sellTickets) { service_tsf.getTicketSalesFormView(event);}
        else if (event.getSource() == eventsAndInformation) { service_d.getDistributorEventsView(event);}
        else if (event.getSource() == notifications) { service_d.getDistributorNotificationsView(event);}
        else if (event.getSource() == updateDeleteForms) { service_tsf.getUpdateDeleteTicketSalesFormView(event);}
        else if (event.getSource() == logOut) { service_adm.getLogInView(event);}}
}



