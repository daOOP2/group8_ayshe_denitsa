package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.UpdateDelete;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventPlacesService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventPlacesModel;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class UpdateDeleteEventPlacesController  implements EventHandler<MouseEvent> {

    private final OrganizerService service_o = OrganizerService.getInstance();
    private final EventPlacesService service_ep = EventPlacesService.getInstance();

    @FXML
    private Button delete, menu, update, load;

    @FXML private TextField result, eventName, placeType, numberOfPlaces;

    @FXML private ListView <String> eventPlacesView;

    @FXML private void initialize() {
        menu.setOnMouseClicked(this); delete.setOnMouseClicked(this);
        update.setOnMouseClicked(this); load.setOnMouseClicked(this);
        result.setEditable(false);
    }

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == delete)
        {

        }
        else if(event.getSource()==update)
        {
            EventPlacesModel ep = new EventPlacesModel();
            ep.setEvent_name(eventName.getText());
            ep.setPlace_type(placeType.getText());
           if( service_ep.UpdateEventPlaces(ep,Integer.parseInt(numberOfPlaces.getText())))
           {
               result.setText("Successfully Added!");
           }
           else
           {
               result.setText("Incorrect Data!");
           }
        }
        else if(event.getSource()==load)
        {
            ObservableList<String> s = service_ep.getEventPlacesByEventName(eventName.getText());
            eventPlacesView.setItems(s);
        }
        else if (event.getSource() == menu)
        {
            service_o.getOrganizerMenuView(event);
        }
    }
}
