package bg.tu_varna.sit.ticket_centar.business.servicec;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import bg.tu_varna.sit.ticket_centar.data.entities.Organizer;
import bg.tu_varna.sit.ticket_centar.data.entities.TicketSalesForm;
import bg.tu_varna.sit.ticket_centar.data.repositories.OrganizerRepository;
import bg.tu_varna.sit.ticket_centar.data.repositories.TicketSalesFormRepository;
import bg.tu_varna.sit.ticket_centar.presentation.models.DistributorModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.OrganizerModel;
import bg.tu_varna.sit.ticket_centar.presentation.models.TicketSalesFormModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class OrganizerService {

    private final OrganizerRepository repository = OrganizerRepository.getInstance();
    private final AdministratorService service_adm = AdministratorService.getInstance();
    private String username;

    public void setUsername(String username){this.username=username;}
    public String getUsername(){return username;}

    public static OrganizerService getInstance() { return OrganizerService.OrganizerServiceHolder.INSTANCE;}

    private static class OrganizerServiceHolder { public static final OrganizerService INSTANCE = new OrganizerService();}

    public ObservableList<OrganizerModel> getAllOrganizers() {
        List<Organizer> organizers = repository.getAll();
        return FXCollections.observableList(
                organizers
                        .stream()
                        .map(o -> new OrganizerModel(
                                o.getOrganizerFirstName(),
                                o.getOrganizerLastName(),
                                o.getOrganizerUsername(),
                                o.getOrganizerPassword(),
                                o.getOrganizerEmail(),
                                o.getOrganizerPhoneNumber(),
                                o.getOrganizerAddress(),
                                o.getOrganizerHonorarium(),
                                o.getAdmin().getAdminUsername(),
                                o.getOrganizerId()
                        )).collect(Collectors.toList()));}

    public Organizer getOrganizerByUsername(String username){
        List<Organizer>organizers=OrganizerRepository.getInstance().getAll();
        Organizer org = new Organizer();
        for(Organizer o : organizers){
            if(o.getOrganizerUsername().equals(username)){
                org=o;
            }
        }
        return org;
    }

    public boolean LogInOrganizer(String username, String password){
        boolean login=false;
        OrganizerModel organizer = new OrganizerModel();
        organizer.setOrganizer_username(username);
        organizer.setOrganizer_password(password);
        this.username = username;
        ObservableList<OrganizerModel> allOrganizers = getAllOrganizers();
        for(OrganizerModel o:allOrganizers ) {
            if((o.getOrganizer_username().equals(organizer.getOrganizer_username()))&&(o.getOrganizer_password().equals(organizer.getOrganizer_password()))){
                login=true;
            }
        }
        return login;
    }

    public boolean SaveOrganizer( OrganizerModel model){
        List<Organizer>organizers= OrganizerRepository.getInstance().getAll();

        Organizer org = new Organizer();
        org.setOrganizerFirstName(model.getOrganizer_first_name());
        org.setOrganizerLastName(model.getOrganizer_last_name());
        org.setOrganizerUsername(model.getOrganizer_username());
        org.setOrganizerPassword(model.getOrganizer_password());
        org.setOrganizerEmail(model.getOrganizer_email());
        org.setOrganizerPhoneNumber(model.getOrganizer_phone_number());
        org.setOrganizerAddress(model.getOrganizer_address());
        org.setOrganizerHonorarium(model.getOrganizer_honorarium());
        org.setAdmin(service_adm.getAdminByUsername(model.getAdmin_username()));
        org.setOrganizerId(model.getOrganizer_id());

        for(Organizer organizer:organizers){
            if((organizer.getOrganizerUsername().equals(org.getOrganizerUsername()))||(organizer.getOrganizerPassword().equals(org.getOrganizerPassword()))||(organizer.getOrganizerEmail().equals(org.getOrganizerEmail()))||(organizer.getOrganizerPhoneNumber().equals(org.getOrganizerPhoneNumber())))
            {
                return false;
            }}

        repository.save(org);
        return true;
    }

    public boolean checkInputData(OrganizerModel model){
        if(model.getOrganizer_phone_number().length()!=13){return false;}
        if(model.getOrganizer_honorarium()<0){return false;}
        if((model.getOrganizer_id()>9999)||(model.getOrganizer_id()<1000)){return false;}
        return true;}

    public OrganizerModel getOrganizerInfo(String username){
        OrganizerModel o = new OrganizerModel();
        o.setOrganizer_username(username);
        List<OrganizerModel> organizers = getAllOrganizers();
        for(OrganizerModel org:organizers){ if((org.getOrganizer_username().equals(o.getOrganizer_username()))) { o=org; }}
        return o; }

    public OrganizerModel getOrganizerModelByID(Long ID){
        OrganizerModel org = new OrganizerModel();
        org.setOrganizer_id(ID);
        List<OrganizerModel> organizers = getAllOrganizers();
        for(OrganizerModel o:organizers){ if((o.getOrganizer_id().equals(org.getOrganizer_id()))) { org=o; }}
        return org;}


    public boolean CheckPhoneNumberIfExistsOrCorrect(String phoneNumber, Long ID)
    {
        if(phoneNumber.length()!=13) { return false; }

        List<OrganizerModel> all = getAllOrganizers();
        for(OrganizerModel o : all)
        {
            if(o.getOrganizer_phone_number().equals(phoneNumber)&&(!o.getOrganizer_id().equals(ID))) { return false; }
        }
        return true;
    }

    public boolean CheckEmailIfExists(String email, Long ID)
    {
        List<OrganizerModel> all = getAllOrganizers();
        for(OrganizerModel o : all)
        {
            if((o.getOrganizer_email().equals(email))&&(!o.getOrganizer_id().equals(ID))) { return false; }
        }
        return true;
    }

    public boolean UpdateOrganizer(OrganizerModel model, Long ID)
    {
       if(!CheckPhoneNumberIfExistsOrCorrect(model.getOrganizer_phone_number(), ID)) {return false;}
       else if(model.getOrganizer_honorarium()<0) {return false;}
       else if(!CheckEmailIfExists(model.getOrganizer_email(), ID)) {return false;}
        List <Organizer> all = OrganizerRepository.getInstance().getAll();
        for(Organizer o : all) {
            if(o.getOrganizerId().equals(ID)) {
                if(o.getAdmin().getAdminUsername().equals(service_adm.getUsername())) {
                    o.setOrganizerEmail(model.getOrganizer_email());
                    o.setOrganizerPhoneNumber(model.getOrganizer_phone_number());
                    o.setOrganizerAddress(model.getOrganizer_address());
                    o.setOrganizerHonorarium(model.getOrganizer_honorarium());
                    repository.update(o);}}}
        return true;
    }

    public void getOrganizerMenuView(MouseEvent event){ try{
        Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.ORGANIZER_MENU_VIEW)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getNewOrganizerView(MouseEvent event){try{
            Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.NEW_ORGANIZER_VIEW)));
            Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();} catch (IOException e) { System.err.printf("Error: %s%n", e.getMessage());}}

    public void getProfileOrganizersView(MouseEvent event){ try{
            Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.ORGANIZERS_PROFILE_VIEW)));
            Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getOrganizerNotificationsView(MouseEvent event){ try{
        Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.ORGANIZER_NOTIFICATIONS)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getOrganizerEventsView(MouseEvent event){ try{
        Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.ORGANIZER_EVENTS)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getUpdateOrganizerView(MouseEvent event){try{
        Parent root =FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.UPDATE_ORGANIZER_VIEW)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}
    catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

}