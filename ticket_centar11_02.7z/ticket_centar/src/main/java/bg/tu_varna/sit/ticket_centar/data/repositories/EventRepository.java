package bg.tu_varna.sit.ticket_centar.data.repositories;
import bg.tu_varna.sit.ticket_centar.data.access.Connection;
import bg.tu_varna.sit.ticket_centar.data.entities.Event;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.LinkedList;
import java.util.List;

public class EventRepository implements DAORepository<Event> {

    private static final Logger log = Logger.getLogger(EventRepository.class);

    public static EventRepository getInstance() { return EventRepository.EventRepositoryHolder.INSTANCE;}

    private static class EventRepositoryHolder {
        public static final EventRepository INSTANCE = new EventRepository();
    }

    @Override
    public void save(Event event) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(event);
            log.info("Event saved successfully");
        } catch (Exception ex) {
            log.error("Event save error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void update(Event event) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            Event e = session.get(Event.class, event.getEventId());
            e.setEventType(event.getEventType());
            e.setEventStatus(event.getEventStatus());
            e.setEventName(event.getEventName());
            e.setEventDetails(event.getEventDetails());
            e.setAddress(event.getAddress());
            e.setEventNumberOfPlaces(event.getEventNumberOfPlaces());
            e.setMaxNumberOfTicketsPerPerson(event.getMaxNumberOfTicketsPerPerson());
            session.update(e);
            log.info("Event updated successfully");
        } catch (Exception ex) {
            log.error("Event updated error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void delete(Event event) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            Event e = session.get(Event.class, event.getEventId());
            session.delete(event);
            log.info("Event deleted successfully");
        } catch (Exception ex) {
            log.error("Event delete error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public List<Event> getAll() {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        List<Event> Event = new LinkedList<>();
        try {
            String jpql = "SELECT e FROM Event  e";
            Event.addAll(session.createQuery(jpql, Event.class).getResultList());
            log.info("Get all Events");
        } catch (Exception ex) {
            log.error("Get Event error: " + ex.getMessage());
        } finally {
            transaction.commit();
           // Connection.openSessionClose();
        }

        return Event;
    }

}


