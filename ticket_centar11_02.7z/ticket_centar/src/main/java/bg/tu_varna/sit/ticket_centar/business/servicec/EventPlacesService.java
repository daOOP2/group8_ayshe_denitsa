package bg.tu_varna.sit.ticket_centar.business.servicec;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import bg.tu_varna.sit.ticket_centar.data.entities.EventPlaces;
import bg.tu_varna.sit.ticket_centar.data.entities.PlacePrice;
import bg.tu_varna.sit.ticket_centar.data.entities.TicketSalesForm;
import bg.tu_varna.sit.ticket_centar.data.repositories.EventPlacesRepository;
import bg.tu_varna.sit.ticket_centar.data.repositories.PlacePriceRepository;
import bg.tu_varna.sit.ticket_centar.data.repositories.TicketSalesFormRepository;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventPlacesModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class EventPlacesService {

    private final EventPlacesRepository repository = EventPlacesRepository.getInstance();
    private final EventService service_event = EventService.getInstance();
    private final PlacePriceService service_place_price = PlacePriceService.getInstance();
    private final OrganizerService service_o = OrganizerService.getInstance();

    public static EventPlacesService getInstance() {

        return EventPlacesService.EventPlacesServiceHolder.INSTANCE;
    }

    private static class EventPlacesServiceHolder {
        public static final EventPlacesService INSTANCE = new EventPlacesService();
    }

    public ObservableList<EventPlacesModel> getAllEventPlaces() {
        List<EventPlaces> eventPlaces = repository.getAll();

        return FXCollections.observableList(
                eventPlaces
                        .stream()
                        .map(ep -> new EventPlacesModel(
                                ep.getEvent().getEventName(),
                                ep.getPlacePrice().getPlaceType(),
                                ep.getNumberOfTickets()
                        )).collect(Collectors.toList()));
    }

    public ObservableList <String> getEventPlacesByEventName (String name) // load update
    {
        ObservableList <String> result_list = FXCollections.observableArrayList();
        List <EventPlaces> all = EventPlacesRepository.getInstance().getAll();
        for(EventPlaces e : all )
        {
            if(e.getEvent().getEventName().equals(name))
            {
                String s = "Type: "+ e.getPlacePrice().getPlaceType() + " Number Of Places:"+ e.getNumberOfTickets() +" Price: "+ e.getPlacePrice().getPlacePrice();
                result_list.add(s);
            }
        }
        return result_list;
    }

    public boolean SaveEventPlaces(EventPlacesModel model){

        List<EventPlaces>eventPlaces= EventPlacesRepository.getInstance().getAll();
        int max = service_event.getEventByName(model.getEvent_name()).getEventNumberOfPlaces();
        int used=0;

        EventPlaces ep = new EventPlaces();
        ep.setEvent(service_event.getEventByName(model.getEvent_name()));
        ep.setPlacePrice(service_place_price.getPlaceByType(model.getPlace_type()));
        ep.setNumberOfTickets(model.getNumber_of_tickets());

        for(EventPlaces p:eventPlaces){ //if exists
            if((p.getEvent().getEventName().equals(ep.getEvent().getEventName()))&&(p.getPlacePrice().getPlaceType().equals(ep.getPlacePrice().getPlaceType())))
            {return false;}}


        for(EventPlaces p : eventPlaces){  //number of distributed tickets
            if(p.getEvent().getEventName().equals(ep.getEvent().getEventName()))
            {  used = used + p.getNumberOfTickets();}
        }
        if(ep.getNumberOfTickets()>(max-used)){return false;}

        repository.save(ep);
        return true;
    }

    public boolean UpdateEventPlaces(EventPlacesModel model, int number_of_tickets)
    {
        List<EventPlaces>all = EventPlacesRepository.getInstance().getAll();
        List<TicketSalesForm>allForms = TicketSalesFormRepository.getInstance().getAll();
        int max = service_event.getEventByName(model.getEvent_name()).getEventNumberOfPlaces();
        int used=0;
        int old = 0;
        int sold=0;

        for(EventPlaces p : all){     // number of distributed tickets
            if((p.getEvent().getEventName().equals(model.getEvent_name())))
            {
                used = used + p.getNumberOfTickets();
                if(p.getPlacePrice().getPlaceType().equals(model.getPlace_type()))
                {old = old + p.getNumberOfTickets();}
            }}

        if((number_of_tickets>(max-used+old))||(number_of_tickets<=0)){return false;}

        for(TicketSalesForm t : allForms) {  // number of sold tickets for type
            if(t.getPlacePrice().getPlaceType().equals(model.getPlace_type()))
            {sold++;}}

        if(sold>number_of_tickets)  {  return false;   }

        for(EventPlaces e : all)
        {
            if(e.getEvent().getOrganizer().getOrganizerUsername().equals(service_o.getUsername())){
                if ((e.getEvent().getEventName().equals(model.getEvent_name()))&&(e.getPlacePrice().getPlaceType().equals(model.getPlace_type()))) {

                        e.setNumberOfTickets(number_of_tickets);
                        repository.update(e);

                }}}
        return true;
    }

    public void getEventPlacesView(MouseEvent event){ try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.EVENT_PLACES)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getUpdateDeleteEventPlacesView(MouseEvent event){ try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.UPDATE_DELETE_EVENT_PLACES)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

}