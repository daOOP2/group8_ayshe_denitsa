package bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Profiles;
import bg.tu_varna.sit.ticket_centar.business.servicec.AdministratorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.OrganizerModel;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

public class ProfileOrganizerController implements EventHandler<MouseEvent> {

    private final OrganizerService service = OrganizerService.getInstance();
    private final AdministratorService service_adm = AdministratorService.getInstance();

    @FXML private ListView<OrganizerModel> listViewOrganizer;

    @FXML private Button  buttonMenu;

    @FXML private void initialize() {
        buttonMenu.setOnMouseClicked(this);
        ObservableList<OrganizerModel> organizers = service.getAllOrganizers();
        listViewOrganizer.setItems(organizers);
    }

    @Override public void handle(MouseEvent event)
    {
        if (event.getSource() == buttonMenu) { service_adm.getAdminView(event); }
        }
    }



