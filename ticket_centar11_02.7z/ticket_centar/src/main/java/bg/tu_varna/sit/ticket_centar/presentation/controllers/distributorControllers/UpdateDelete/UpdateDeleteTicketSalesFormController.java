package bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.UpdateDelete;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.TicketSalesFormService;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class UpdateDeleteTicketSalesFormController implements EventHandler<MouseEvent> {

    private final DistributorService service_d = DistributorService.getInstance();
    private final TicketSalesFormService service_tsf = TicketSalesFormService.getInstance();

    @FXML private Button delete, menu, update, loadClientName;

    @FXML private TextField oldPhoneNumber, newPhoneNumber, clientFullName, result, bg, bg_2;

    @FXML private void initialize() {
        menu.setOnMouseClicked(this); delete.setOnMouseClicked(this);
        update.setOnMouseClicked(this); loadClientName.setOnMouseClicked(this);
        bg.setText("+359"); bg.setEditable(false);
        bg_2.setText("+359"); bg_2.setEditable(false);
        result.setEditable(false); clientFullName.setEditable(false);
       }

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == delete)
        {
            service_tsf.DeleteTicketSalesForm(bg.getText()+oldPhoneNumber.getText());
        }
        else if(event.getSource()==update)
        {
               if( !service_tsf.UpdateTicketSalesForm(bg_2.getText() + oldPhoneNumber.getText(), bg_2.getText() + newPhoneNumber.getText()))
               {
                   result.setText("Incorrect Data!");
               }
        }
        else if(event.getSource()==loadClientName)
        {
            clientFullName.setText(service_tsf.getClientFullName(bg.getText()+oldPhoneNumber.getText()));
        }
        else if (event.getSource() == menu)
        {
            service_d.getDistributorMenuView(event);
        }
    }
}
