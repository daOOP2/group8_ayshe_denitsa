package bg.tu_varna.sit.ticket_centar.data.entities;
import javax.persistence.*;
import java.util.Set;

@Table(name = "events")
@Entity
public class Event {

    @Column(name = "event_name", nullable = false, unique = true)
    private String event_name;

    @Column(name = "event_type", nullable = false)
    private String event_type;

    @Column(name = "event_status", nullable = false)
    private String event_status;

    @Column(name = "event_number_of_places", nullable = false)
    private int event_number_of_places;

    @Column(name = "event_date", nullable = false)
    private String event_date;

    @Column(name = "max_number_of_tickets_per_person", nullable = false)
    private int max_number_of_tickets_per_person;

    @Id
    @Column(name = "event_id", nullable = false)
    private Long event_id;

    @OneToMany(mappedBy = "event", fetch = FetchType.LAZY)
    private Set<EventDistributor> eventDistributorSet;

    @OneToMany(mappedBy = "event", fetch = FetchType.LAZY)
    private Set<EventPlaces> eventPlacesSet;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizer_id", nullable = false)
    private Organizer organizer;

    @Column(name = "address", nullable = false)
    private String address;

    @Column(name="date_of_creation", nullable = false)
    private String date_of_creation;

    @Column(name="event_details", nullable = false)
    private String event_details;

    public Event(){}

    public Long getEventId() {
        return event_id;
    }
    public void setEventId(Long event_id) {
        this.event_id = event_id;
    }

    public String getEventName() {
        return event_name;
    }
    public void setEventName(String event_name) {
        this.event_name = event_name;
    }

    public String getEventType() {
        return event_type;
    }
    public void setEventType(String event_type) {
        this.event_type = event_type;
    }

    public String getEventStatus() {
        return event_status;
    }
    public void setEventStatus(String event_status) {
        this.event_status = event_status;
    }

    public int getEventNumberOfPlaces() {
        return event_number_of_places;
    }
    public void setEventNumberOfPlaces(int event_number_of_places) {this.event_number_of_places = event_number_of_places;}

    public String getEventDate() {
        return event_date;
    }
    public void setEventDate(String event_date) {
        this.event_date = event_date;
    }

    public String getDateOfCreation() {
        return date_of_creation;
    }
    public void setDateOfCreation(String date_of_creation) {
        this.date_of_creation=date_of_creation;
    }

    public int getMaxNumberOfTicketsPerPerson() {
        return max_number_of_tickets_per_person;
    }
    public void setMaxNumberOfTicketsPerPerson(int max_number_of_tickets_per_person) {this.max_number_of_tickets_per_person = max_number_of_tickets_per_person;}

    public Organizer getOrganizer() {return organizer;}
    public void setOrganizer(Organizer organizer) {this.organizer = organizer;}

    public Set<EventDistributor> getEventDistributorSet() {return eventDistributorSet;}
    public void setEventDistributorSet(Set<EventDistributor> eventDistributorSet) {this.eventDistributorSet = eventDistributorSet;}

    public Set<EventPlaces> getEventPlacesSet() {return eventPlacesSet;}
    public void setEventPlacesSet(Set<EventPlaces> eventPlacesSet) {this.eventPlacesSet = eventPlacesSet;}

    public String getAddress(){return address;}
    public void setAddress(String address){this.address=address;}

    public String getEventDetails() {
        return event_details;
    }
    public void setEventDetails(String event_details) {
        this.event_details=event_details;
    }

    @Override
    public String toString() {
        return "event{" +
                "event_name='" + event_name +'\''+
                "event_type='" + event_type +'\''+
                "event_status='" + event_status +'\''+
                "event_details='" + event_details +'\''+
                "address='" + address +'\''+
                "event_number_of_places=" + event_number_of_places +
                "event_date='" + event_date +'\''+
                "date_of_creation='" + date_of_creation +'\''+
                "max_number_of_tickets_per_person=" + max_number_of_tickets_per_person +
                ", event_id=" + event_id +
                ", organizer=" + organizer +
                ", eventDistributorSet=" + eventDistributorSet +
                ", eventPlacesSet=" + eventPlacesSet +
                '}';
    }

}
