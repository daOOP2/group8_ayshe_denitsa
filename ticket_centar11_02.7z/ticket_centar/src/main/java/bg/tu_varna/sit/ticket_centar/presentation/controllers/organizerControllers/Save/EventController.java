package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Save;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.time.LocalDate;

public class EventController  implements EventHandler<MouseEvent> {

    private final EventService service_e = EventService.getInstance();
    private final OrganizerService service_o = OrganizerService.getInstance();

    @FXML private TextField tfEventName, tfEventType, tfEventDetails, tfEventNumberOfPlaces, tfMaxNumberOfTicketsPerPerson, tfEventID, tfResult, tfAddress;

    @FXML private DatePicker date_event;

    @FXML private Button buttonMenu, buttonCreate;

    @FXML private void initialize() {
        buttonMenu.setOnMouseClicked(this); buttonCreate.setOnMouseClicked(this);
        tfResult.setEditable(false);}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == buttonCreate) {
            if(Integer.parseInt(tfEventNumberOfPlaces.getText())<0){tfEventNumberOfPlaces.setText("IncorrectData");}
            else if((Integer.parseInt(tfMaxNumberOfTicketsPerPerson.getText())<0)||(Integer.parseInt(tfMaxNumberOfTicketsPerPerson.getText())>Integer.parseInt(tfEventNumberOfPlaces.getText()))){tfMaxNumberOfTicketsPerPerson.setText("Incorrect Data!");}
            else if((Integer.parseInt(tfEventID.getText())>9999)||(Integer.parseInt(tfEventID.getText())<1000)){tfEventID.setText("Incorrect Data!");}
            else{
            EventModel newEvent = new EventModel(tfEventName.getText().toLowerCase(), tfEventType.getText().toLowerCase(), service_e.setStatus(String.valueOf(date_event.getValue())), Integer.parseInt(tfEventNumberOfPlaces.getText()),String.valueOf(date_event.getValue()),Integer.parseInt(tfMaxNumberOfTicketsPerPerson.getText()), Long.parseLong(tfEventID.getText()), service_o.getUsername(), tfAddress.getText().toLowerCase(), String.valueOf(LocalDate.now()), tfEventDetails.getText());
            boolean result =service_e.SaveEvent(newEvent);
            if(result){tfResult.setText("Added Successfully!");}
            else{tfResult.setText("Save Error!");
            }}}
        else if (event.getSource() == buttonMenu) { service_o.getOrganizerMenuView(event);}}
    }






