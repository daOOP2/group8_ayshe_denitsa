package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.OrganizerProfile;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;

import java.time.LocalDate;

public class OrganizerEventsController implements EventHandler<MouseEvent> {

    private final EventService service_e = EventService.getInstance();
    private final OrganizerService service_o = OrganizerService.getInstance();

    @FXML private Button buttonShow, buttonMenu;
    @FXML private DatePicker from, to;

    @FXML private ListView<String> listViewOrganizerEvent;

    @FXML private void initialize() {
        buttonShow.setOnMouseClicked(this);buttonMenu.setOnMouseClicked(this);}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == buttonShow) {
            LocalDate date_from = from.getValue();
            LocalDate date_to = to.getValue();
            ObservableList<String> events = service_e.getEventsByOrganizer(service_o.getUsername(), date_from, date_to);
            listViewOrganizerEvent.setItems(events);}
        else if (event.getSource() == buttonMenu) { service_o.getOrganizerMenuView(event); }}
}

