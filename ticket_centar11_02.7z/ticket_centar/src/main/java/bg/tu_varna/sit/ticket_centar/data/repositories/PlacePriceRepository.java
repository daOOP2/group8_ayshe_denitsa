package bg.tu_varna.sit.ticket_centar.data.repositories;
import bg.tu_varna.sit.ticket_centar.data.access.Connection;
import bg.tu_varna.sit.ticket_centar.data.entities.PlacePrice;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.LinkedList;
import java.util.List;

public class PlacePriceRepository implements DAORepository<PlacePrice> {

    private static final Logger log = Logger.getLogger(PlacePriceRepository.class);

    public static PlacePriceRepository getInstance() { return PlacePriceRepository.PlacePriceRepositoryHolder.INSTANCE;}

    private static class PlacePriceRepositoryHolder {
        public static final PlacePriceRepository INSTANCE = new PlacePriceRepository();
    }

    @Override
    public void save(PlacePrice place_price) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(place_price);
            log.info("Place Price saved successfully");
        } catch (Exception ex) {
            log.error("Place Price save error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void update(PlacePrice place_price) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            PlacePrice p = session.get(PlacePrice.class, place_price.getPlacePriceId());
            p.setPlacePrice(place_price.getPlacePrice());
            session.update(p);
            log.info("Place Price updated successfully");
        } catch (Exception ex) {
            log.error("Place Price update error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void delete(PlacePrice place_price) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            PlacePrice p = session.get(PlacePrice.class, place_price.getPlacePriceId());
            session.delete(p);
            log.info("Place Price deleted successfully");
        } catch (Exception ex) {
            log.error("Place Price delete error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public List<PlacePrice> getAll() {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        List<PlacePrice> PlacePrice = new LinkedList<>();
        try {
            String jpql = "SELECT pp FROM PlacePrice  pp";
            PlacePrice.addAll(session.createQuery(jpql, PlacePrice.class).getResultList());
            log.info("Get all Places Prices");
        } catch (Exception ex) {
            log.error("Get Place Price error: " + ex.getMessage());
        } finally {
            transaction.commit();
           // Connection.openSessionClose();
        }

        return PlacePrice;
    }
}


