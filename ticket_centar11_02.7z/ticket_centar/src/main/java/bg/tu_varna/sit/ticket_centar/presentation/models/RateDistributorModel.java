package bg.tu_varna.sit.ticket_centar.presentation.models;

public class RateDistributorModel {
    private Long organizer_id;
    private Long distributor_id;
    private double rating_percentage;

    public RateDistributorModel(){
        this.organizer_id= 0L;
        this.distributor_id= 0L;
        this.rating_percentage=0.0;
    }

    public RateDistributorModel(Long organizer_id, Long distributor_id, double rating_percentage){
        this.organizer_id=organizer_id;
        this.distributor_id=distributor_id;
        this.rating_percentage=rating_percentage;
    }

    public void setOrganizer_id(Long organizer_id){this.organizer_id=organizer_id;}
    public Long getOrganizer_id(){return organizer_id;}

    public void setDistributor_id(Long distributor_id){this.distributor_id=distributor_id;}
    public Long getDistributor_id(){return distributor_id;}

    public void setRating_percentage(double rating_percentage){this.rating_percentage=rating_percentage;}
    public double getRating_percentage(){return rating_percentage;}

    @Override
    public String toString() {
        return  String.format("%s | %s | %s", organizer_id, distributor_id, rating_percentage);
    }
}
