package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Notifications;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.business.servicec.TicketSalesFormService;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventModel;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class OrganizerNotificationsController implements EventHandler<MouseEvent> {

    private final OrganizerService service_o = OrganizerService.getInstance();
    private final EventService service_e = EventService.getInstance();
    private final TicketSalesFormService service_t = TicketSalesFormService.getInstance();

    @FXML private Button returnMenu;

    @FXML private TextField date;

    @FXML private ListView<String> sold_tickets;

    @FXML private ListView<String> events_this_month;

    @FXML private void initialize() {returnMenu.setOnMouseClicked(this);


        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        date.setText(" Today is :   "+dtf.format(now));
        date.setEditable(false);
        ObservableList<String> events = service_e.eventsThisMonth();
        events_this_month.setItems(events);
        ObservableList<String>sold = service_t.soldTicketsForLastWeek(service_o.getUsername());
        sold_tickets.setItems(sold);
    }

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == returnMenu) {
            service_o.getOrganizerMenuView(event);
        }
    }
}

