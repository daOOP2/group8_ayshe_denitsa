package bg.tu_varna.sit.ticket_centar.business.servicec;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import bg.tu_varna.sit.ticket_centar.data.entities.PlacePrice;
import bg.tu_varna.sit.ticket_centar.data.repositories.PlacePriceRepository;
import bg.tu_varna.sit.ticket_centar.presentation.models.PlacePriceModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class PlacePriceService {

    private final PlacePriceRepository repository = PlacePriceRepository.getInstance();

    public static PlacePriceService getInstance() {

        return PlacePriceService.PlacePriceServiceHolder.INSTANCE;
    }

    private static class PlacePriceServiceHolder {
        public static final PlacePriceService INSTANCE = new PlacePriceService();
    }

    public ObservableList<PlacePriceModel> getAllPrices() {
        List<PlacePrice> prices = repository.getAll();

        return FXCollections.observableList(
                prices
                        .stream()
                        .map(pp -> new PlacePriceModel(
                                pp.getPlaceType(),
                                pp.getPlacePrice()
                        )).collect(Collectors.toList()));
    }

    public double loadPrice (String type)  // load update
    {
        double price = 0;
        List<PlacePriceModel> all = getAllPrices();
        for(PlacePriceModel p : all)
        {
            if(p.getPlace_type().equals(type))
            {
                price = p.getPlace_price();
            }
        }
        return price;
    }

    public PlacePrice getPlaceByType(String type){
        List<PlacePrice>places= PlacePriceRepository.getInstance().getAll();
        PlacePrice pp = new PlacePrice();
        for(PlacePrice p : places){if(p.getPlaceType().equals(type)){pp=p;}}
        return pp;}

    public boolean SavePlacePrice(PlacePriceModel model){
        List<PlacePrice>placePrices= PlacePriceRepository.getInstance().getAll();

        PlacePrice pp = new PlacePrice();
        pp.setPlaceType(model.getPlace_type());
        pp.setPlacePrice(model.getPlace_price());

        for(PlacePrice placePrice:placePrices){
            if((placePrice.getPlaceType().equals(pp.getPlaceType())))
            {return false;}}

        repository.save(pp);
        return true;}

    public boolean UpdatePlacePrice(String type, Double new_price)
    {
        List<PlacePrice> all = PlacePriceRepository.getInstance().getAll();
        for(PlacePrice p : all)
        {
            if(p.getPlaceType().equals(type)) {
                if (new_price>0) {
                    p.setPlacePrice(new_price);
                    repository.update(p);
                }
                else{
                    return false;
                }
            }
        }
        return true;
    }

    public void DeletePlacePrice(String type)
    {
        List<PlacePrice> all = PlacePriceRepository.getInstance().getAll();
        for(PlacePrice p : all)
        {
            if(p.getPlaceType().equals(type))
            {
                    repository.delete(p);
            }
        }
    }

    public void getPlacePriceView(MouseEvent event){ try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.PLACE_PRICE)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

    public void getUpdateDeletePlacePriceView(MouseEvent event){ try{
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(Constants.View.UPDATE_DELETE_PLACE_PRICE)));
        Stage stage =(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();}  catch (IOException e) {System.err.printf("Error: %s%n", e.getMessage());}}

}
