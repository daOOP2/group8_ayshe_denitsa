package bg.tu_varna.sit.ticket_centar.presentation.controllers.distributorControllers.Notifications;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventDistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventService;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DistributorNotificationsController implements EventHandler<MouseEvent> {

    private final DistributorService service_d = DistributorService.getInstance();
    private final EventDistributorService service_ed = EventDistributorService.getInstance();
    private final EventService service_e = EventService.getInstance();

    @FXML private Button returnMenu;

    @FXML private TextField date;

    @FXML private ListView<String> new_events;

    @FXML private ListView<String> events_this_month;

    @FXML private void initialize() {
        returnMenu.setOnMouseClicked(this);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        date.setText(" Today is :   "+dtf.format(now));
        date.setEditable(false);
        ObservableList<String> e = service_ed.getLastAddedEvents(service_d.getUsername());
        new_events.setItems(e);
        ObservableList<String> d = service_e.eventsThisMonth();
        events_this_month.setItems(d);
    }

    @Override public void handle(MouseEvent event) {if (event.getSource() == returnMenu) { service_d.getDistributorMenuView(event);}}
}

