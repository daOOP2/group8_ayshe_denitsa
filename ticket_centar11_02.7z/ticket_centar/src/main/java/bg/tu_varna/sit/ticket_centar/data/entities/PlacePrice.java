package bg.tu_varna.sit.ticket_centar.data.entities;

import javax.persistence.*;
import java.util.Set;

@Table(name = "place_prices")
@Entity
public class PlacePrice {

    @Column(name = "place_type", nullable = false)
    private String place_type;

    @Column(name = "place_price", nullable = false)
    private double place_price;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "place_price_id", nullable = false)
    private Long place_price_id;

    @OneToMany(mappedBy = "place_price", fetch = FetchType.LAZY)
    private Set<EventPlaces> eventPlacesSet;

    @OneToMany(mappedBy = "place_price", fetch = FetchType.LAZY)
    private Set<TicketSalesForm> ticketSalesFormsSet;

    public Long getPlacePriceId() {
        return place_price_id;
    }
    public void setPlacePriceId(Long place_price_id) {
        this.place_price_id = place_price_id;
    }

    public double getPlacePrice() {
        return place_price;
    }
    public void setPlacePrice(double place_price) {
        this.place_price = place_price;
    }

    public String getPlaceType() {
        return place_type;
    }
    public void setPlaceType(String place_type) {
        this.place_type = place_type;
    }

    public Set<EventPlaces> getEventPlacesSet() {return eventPlacesSet;}
    public void setEventPlacesSet(Set<EventPlaces> eventPlacesSet) {this.eventPlacesSet = eventPlacesSet;}

    public Set<TicketSalesForm> getTicketSalesFormsSet() {return ticketSalesFormsSet;}
    public void setTicketSalesFormsSet(Set<TicketSalesForm> ticketSalesFormSet) {this.ticketSalesFormsSet = ticketSalesFormSet;}

    public PlacePrice(){}

    @Override
    public String toString() {
        return "place_price{" +
                ", place_type='" + place_type + '\'' +
                ", place_price=" + place_price +
                ", place_price_id=" + place_price_id +
                ", eventPlacesSet=" + eventPlacesSet +
                ", ticketSalesFormSet=" + ticketSalesFormsSet +
                '}';
    }
}
