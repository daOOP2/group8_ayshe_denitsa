package bg.tu_varna.sit.ticket_centar.presentation.models;

public class OrganizerModel {
    private  String organizer_first_name;
    private  String organizer_last_name;
    private  String organizer_username;
    private  String organizer_password;
    private  String organizer_email;
    private  String organizer_phone_number;
    private  String organizer_address;
    private  Double organizer_honorarium;
    private  String admin_username;
    private  Long organizer_id;

    public OrganizerModel(){
        organizer_first_name="";
        organizer_last_name="";
        organizer_username="";
        organizer_password="";
        organizer_email="";
        organizer_phone_number="";
        organizer_address="";
        organizer_honorarium=0.0;
        admin_username= "";
        organizer_id= 0L;
    }

    public OrganizerModel(String organizer_first_name, String organizer_last_name, String organizer_username, String organizer_password, String organizer_email, String organizer_phone_number, String organizer_address, double organizer_honorarium, String admin_username,Long organizer_id){
        this.organizer_first_name=organizer_first_name;
        this.organizer_last_name=organizer_last_name;
        this.organizer_username=organizer_username;
        this.organizer_password=organizer_password;
        this.organizer_email=organizer_email;
        this.organizer_phone_number=organizer_phone_number;
        this.organizer_address=organizer_address;
        this.organizer_honorarium=organizer_honorarium;
        this.admin_username= admin_username;
        this.organizer_id= organizer_id;
    }

    public String getOrganizer_first_name(){return organizer_first_name;}
    public void setOrganizer_first_name(String organizer_first_name){this.organizer_first_name=organizer_first_name;}

    public String getOrganizer_last_name(){return organizer_last_name;}
    public void setOrganizer_last_name(String organizer_last_name){this.organizer_last_name=organizer_last_name;}

    public String getOrganizer_username(){return organizer_username;}
    public void setOrganizer_username(String organizer_username){this.organizer_username=organizer_username;}

    public String getOrganizer_password(){return organizer_password;}
    public void setOrganizer_password(String organizer_password){this.organizer_password=organizer_password;}

    public String getOrganizer_email(){return organizer_email;}
    public void setOrganizer_email(String organizer_email){this.organizer_email=organizer_email;}

    public String getOrganizer_phone_number(){return organizer_phone_number;}
    public void setOrganizer_phone_number(String organizer_phone_number){this.organizer_phone_number=organizer_phone_number;}

    public String getOrganizer_address(){return organizer_address;}
    public void setOrganizer_address(String organizer_address){this.organizer_address=organizer_address;}

    public double getOrganizer_honorarium(){return organizer_honorarium;}
    public void setOrganizer_honorarium(double organizer_honorarium){this.organizer_honorarium=organizer_honorarium;}

    public Long getOrganizer_id(){return organizer_id;}
    public void setOrganizer_id(Long organizer_id){this.organizer_id=organizer_id;}

    public String getAdmin_username(){return admin_username;}
    public void setAdmin_username(String admin_username){this.admin_username=admin_username;}

    @Override
    public String toString() {
        return  String.format("Name: %s  %s | Username: %s | Password: %s | E-mail: %s | Phone Number: %s | Address: %s | Honorarium: %s | ID: %s | Admin: %s", organizer_first_name, organizer_last_name, organizer_username, organizer_password, organizer_email, organizer_phone_number, organizer_address, organizer_honorarium, admin_username, organizer_id);
    }

}
