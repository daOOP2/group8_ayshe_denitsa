package bg.tu_varna.sit.ticket_centar.data.entities;

import javax.persistence.*;

@Table(name = "distributor_ratings")
@Entity
public class DistributorRating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rating_id", nullable = false)
    private Long rating_id;

    @Column(name = "rating_percentage", nullable = false)
    private double rating_percentage;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizer_id", nullable = false)
    private Organizer organizer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "distributor_id", nullable = false)
    private Distributor distributor;

    public Long getRatingId() {
        return rating_id;
    }
    public void setRatingId(Long rating_id) {
        this.rating_id = rating_id;
    }

    public DistributorRating(){}

    public double getRatingPercentage() {
        return rating_percentage;
    }
    public void setRatingPercentage(double rating_percentage) {
        this.rating_percentage = rating_percentage;
    }

    public Organizer getOrganizer() {return organizer;}
    public void setOrganizer(Organizer organizer) {this.organizer = organizer;}

    public Distributor getDistributor() {return distributor;}
    public void setDistributor(Distributor distributor) {this.distributor = distributor;}

    @Override
    public String toString() {
        return "distributor_rating{" +
                "rating_percentage='" + rating_percentage +'\''+
                ", rating_id=" + rating_id +
                ", organizer=" + organizer +
                ", distributor=" + distributor +
                '}';
    }
}
