package bg.tu_varna.sit.ticket_centar.common;

public class Constants
{
    public  static class View
    {
        public static final String LOG_IN_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/LogInView/LogIn.fxml";



        public static final String ADMIN_MENU_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/adminViews/menu/AdminMenu.fxml";
        public static final String DISTRIBUTOR_MENU_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/distributorViews/menu/DistributorMenu.fxml";
        public static final String ORGANIZER_MENU_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/menu/OrganizerMenu.fxml";



        public static final String NEW_DISTRIBUTOR_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/adminViews/save/NewDistributor.fxml";
        public static final String UPDATE_DISTRIBUTOR_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/adminViews/update/UpdateDistributor.fxml";
        public static final String DISTRIBUTORS_PROFILE_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/adminViews/profiles/ProfileDistributors.fxml";

        public static final String NEW_ORGANIZER_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/adminViews/save/NewOrganizer.fxml";
        public static final String UPDATE_ORGANIZER_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/adminViews/update/UpdateOrganizer.fxml";
        public static final String ORGANIZERS_PROFILE_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/adminViews/profiles/ProfileOrganizers.fxml";



        public static final String TICKET_SALES_FORM = "/bg/tu_varna/sit/ticket_centar/presentation.views/distributorViews/save/TicketSalesForm.fxml";
        public static final String UPDATE_DELETE_TICKET_SALES_FORM = "/bg/tu_varna/sit/ticket_centar/presentation.views/distributorViews/updateORdelete/UpdateDeleteTicketSalesForm.fxml";

        public static final String DISTRIBUTOR_NOTIFICATIONS= "/bg/tu_varna/sit/ticket_centar/presentation.views/distributorViews/notifications/DistributorNotifications.fxml";
        public static final String DISTRIBUTOR_EVENTS = "/bg/tu_varna/sit/ticket_centar/presentation.views/distributorViews/events/DistributorEvents.fxml";



        public static final String EVENT_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/save/NewEvent.fxml";
        public static final String UPDATE_EVENT_VIEW = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/updateORdelete/UpdateEvent.fxml";


        public static final String RATE_DISTRIBUTOR = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/save/RateDistributor.fxml";
        public static final String UPDATE_DELETE_RATE_DISTRIBUTOR = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/updateORdelete/UpdateDeleteDistributorRating.fxml";

        public static final String ORGANIZER_EVENTS = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/events/OrganizerEvents.fxml";
        public static final String ORGANIZER_NOTIFICATIONS = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/notifications/OrganizerNotifications.fxml";

        public static final String EVENT_DISTRIBUTOR = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/save/EventDistributor.fxml";
        public static final String DELETE_EVENT_DISTRIBUTOR = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/updateORdelete/DeleteEventDistributors.fxml";

        public static final String PLACE_PRICE = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/save/PlacePrice.fxml";
        public static final String UPDATE_DELETE_PLACE_PRICE = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/updateORdelete/UpdateDeletePlacePrice.fxml";

        public static final String EVENT_PLACES = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/save/EventPlaces.fxml";
        public static final String UPDATE_DELETE_EVENT_PLACES = "/bg/tu_varna/sit/ticket_centar/presentation.views/organizerViews/updateORdelete/UpdateDeleteEventPlaces.fxml";

    }

    public static class Configurations
    {
        public static final String LOG4J_PROPERTIES = "/bg/tu_varna/sit/ticket_centar/configuration/log4j.properties";
        public static final String hibernate = "/hibernate.cfg.xml";
    }

    public static class Values { public static final String TitleLogIn = "Main View";}
}
