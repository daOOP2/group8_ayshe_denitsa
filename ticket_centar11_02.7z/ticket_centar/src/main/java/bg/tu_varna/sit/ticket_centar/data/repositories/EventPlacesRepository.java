package bg.tu_varna.sit.ticket_centar.data.repositories;
import bg.tu_varna.sit.ticket_centar.data.access.Connection;
import bg.tu_varna.sit.ticket_centar.data.entities.EventPlaces;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.LinkedList;
import java.util.List;

public class EventPlacesRepository implements DAORepository<EventPlaces> {

    private static final Logger log = Logger.getLogger(EventPlacesRepository.class);

    public static EventPlacesRepository getInstance() { return EventPlacesRepository.EventPlacesRepositoryHolder.INSTANCE;}

    private static class EventPlacesRepositoryHolder {
        public static final EventPlacesRepository INSTANCE = new EventPlacesRepository();
    }

    @Override
    public void save(EventPlaces event_places) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(event_places);
            log.info("Event Places saved successfully");
        } catch (Exception ex) {
            log.error("Event Places save error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void update(EventPlaces event_places) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            EventPlaces e = session.get(EventPlaces.class, event_places.getEventPlacesId());
            e.setNumberOfTickets(event_places.getNumberOfTickets());
            session.update(e);
            log.info("Event Places updated successfully");
        } catch (Exception ex) {
            log.error("Event Places update error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void delete(EventPlaces event_places) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.delete(event_places);
            log.info("Event Places deleted successfully");
        } catch (Exception ex) {
            log.error("Event Places delete error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public List<EventPlaces> getAll() {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        List<EventPlaces> EventPlaces = new LinkedList<>();
        try {
             String jpql = "SELECT ep FROM EventPlaces ep";
            EventPlaces.addAll(session.createQuery(jpql, EventPlaces.class).getResultList());
            log.info("Get all Events Places");
        } catch (Exception ex) {
            log.error("Get Event Places error: " + ex.getMessage());
        } finally {
            transaction.commit();
           // Connection.openSessionClose();
        }

        return EventPlaces;
    }
}

