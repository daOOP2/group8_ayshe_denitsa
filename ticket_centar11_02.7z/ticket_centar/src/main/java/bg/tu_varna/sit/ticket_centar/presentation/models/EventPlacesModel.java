package bg.tu_varna.sit.ticket_centar.presentation.models;

public class EventPlacesModel {
    private String event_name;
    private String place_type;
    private int number_of_tickets;

    public EventPlacesModel(){
        event_name = "";
        place_type = "";
        number_of_tickets = 0;
    }

    public EventPlacesModel(String event_name, String place_type, int number_of_tickets){
        this.event_name=event_name;
        this.place_type=place_type;
        this.number_of_tickets=number_of_tickets;
    }

    public String getEvent_name(){return event_name;}
    public void setEvent_name(String event_name){this.event_name=event_name;}

    public String getPlace_type(){return place_type;}
    public void setPlace_type(String place_type){this.place_type=place_type;}

    public int getNumber_of_tickets(){return number_of_tickets;}
    public void setNumber_of_tickets(int number_of_tickets){this.number_of_tickets=number_of_tickets;}

    @Override
    public String toString() {
        return  String.format("%s | %s | %s ", event_name, place_type, number_of_tickets);
    }
}
