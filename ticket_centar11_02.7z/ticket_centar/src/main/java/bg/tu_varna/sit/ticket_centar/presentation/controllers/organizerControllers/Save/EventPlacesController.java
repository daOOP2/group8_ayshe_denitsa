package bg.tu_varna.sit.ticket_centar.presentation.controllers.organizerControllers.Save;
import bg.tu_varna.sit.ticket_centar.business.servicec.EventPlacesService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.presentation.models.EventPlacesModel;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class EventPlacesController implements EventHandler<MouseEvent> {

    private final EventPlacesService service_ep = EventPlacesService.getInstance();
    private final OrganizerService service_org = OrganizerService.getInstance();

    @FXML private Button save, menu;

    @FXML private TextField event_name, place_type, number_of_tickets, result;


    @FXML private void initialize() {save.setOnMouseClicked(this);
        menu.setOnMouseClicked(this); result.setEditable(false);}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == save) {

            if(Integer.parseInt(number_of_tickets.getText())<0){result.setText("Incorrect Data!");}
            else{
            EventPlacesModel epm = new EventPlacesModel(event_name.getText().toLowerCase(), place_type.getText().toLowerCase(), Integer.parseInt(number_of_tickets.getText()));
            boolean r = service_ep.SaveEventPlaces(epm);
            if(r){result.setText("Saved Successfully!");}
            else {result.setText("Save Error!");}
            }}
        else if (event.getSource() == menu) { service_org.getOrganizerMenuView(event); }}
}

