package bg.tu_varna.sit.ticket_centar.presentation.controllers.adminControllers.Menu;
import bg.tu_varna.sit.ticket_centar.business.servicec.AdministratorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.DistributorService;
import bg.tu_varna.sit.ticket_centar.business.servicec.OrganizerService;
import bg.tu_varna.sit.ticket_centar.common.Constants;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

public class AdminMenuController implements EventHandler<MouseEvent> {

    private final OrganizerService service_o = OrganizerService.getInstance();
    private final DistributorService service_d = DistributorService.getInstance();
    private final AdministratorService service_adm = AdministratorService.getInstance();

    @FXML private Button newOrganizer, newDistributor, profileDistributors, profileOrganizers, logOut, updateDistributor, updateOrganizer;

    @FXML private void initialize() { logOut.setOnMouseClicked(this);
        newDistributor.setOnMouseClicked(this); updateDistributor.setOnMouseClicked(this);
        profileDistributors.setOnMouseClicked(this); profileOrganizers.setOnMouseClicked(this);
        newOrganizer.setOnMouseClicked(this); updateOrganizer.setOnMouseClicked(this);}

    @Override public void handle(MouseEvent event) {
        if (event.getSource() == newOrganizer) { service_o.getNewOrganizerView(event);}
        else if (event.getSource() == newDistributor) { service_d.getNewDistributorView(event);}
        else if (event.getSource() == profileOrganizers) {service_o.getProfileOrganizersView(event);}
        else if (event.getSource() == profileDistributors) { service_d.getProfileDistributorsView(event);}
        else if (event.getSource() == logOut) { service_adm.getLogInView(event); }
        else if (event.getSource() == updateDistributor) { service_d.getUpdateDistributorView(event);}
        else if (event.getSource() == updateOrganizer) {service_o.getUpdateOrganizerView(event);}}
}



