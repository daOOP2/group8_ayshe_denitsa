package bg.tu_varna.sit.ticket_centar.data.repositories;
import bg.tu_varna.sit.ticket_centar.data.access.Connection;
import bg.tu_varna.sit.ticket_centar.data.entities.Organizer;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import java.util.LinkedList;
import java.util.List;

public class OrganizerRepository implements DAORepository<Organizer> {

    private static final Logger log = Logger.getLogger(OrganizerRepository.class);

    public static OrganizerRepository getInstance() { return OrganizerRepository.OrganizerRepositoryHolder.INSTANCE;}

    private static class OrganizerRepositoryHolder {
        public static final OrganizerRepository INSTANCE = new OrganizerRepository();
    }

    @Override
    public void save(Organizer organizer) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.save(organizer);
            log.info("Organizer saved successfully");
        } catch (Exception ex) {
            log.error("Organizer save error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void update(Organizer organizer) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
           Organizer o = session.get(Organizer.class, organizer.getOrganizerId());
           o.setOrganizerHonorarium(organizer.getOrganizerHonorarium());
           o.setOrganizerAddress(organizer.getOrganizerAddress());
           o.setOrganizerEmail(organizer.getOrganizerEmail());
           o.setOrganizerPhoneNumber(organizer.getOrganizerPhoneNumber());
            session.update(o);
            log.info("Organizer updated successfully");
        } catch (Exception ex) {
            log.error("Organizer update error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public void delete(Organizer organizer) {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        try {
            session.delete(organizer);
            log.info("Organizer deleted successfully");
        } catch (Exception ex) {
            log.error("Organizer deleted error" + ex.getMessage());
        } finally {
            transaction.commit();
        }
    }

    @Override
    public List<Organizer> getAll() {
        Session session = Connection.openSession();
        Transaction transaction = session.beginTransaction();
        List<Organizer> Organizer = new LinkedList<>();
        try {
            String jpql = "SELECT o FROM Organizer  o";
            Organizer.addAll(session.createQuery(jpql, Organizer.class).getResultList());
            log.info("Get all Organizers");
        } catch (Exception ex) {
            log.error("Get Organizer error: " + ex.getMessage());
        } finally {
            transaction.commit();
          //  Connection.openSessionClose();
        }

        return Organizer;
    }
}

